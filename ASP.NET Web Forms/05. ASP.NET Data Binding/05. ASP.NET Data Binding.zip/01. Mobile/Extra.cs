﻿namespace Mobile
{
    using System;
    using System.Linq;

    public class Extra
    {
        public string Name { get; set; }
    }
}
﻿namespace Mobile
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Producer
    {
        public string Name { get; set; }

        public IList<string> Models { get; set; }
    }
}
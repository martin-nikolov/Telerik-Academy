using System;
using System.Collections.Generic;

namespace EmployeesDataBinding.Models
{
    public partial class Category_Sales_for_1997
    {
        public string CategoryName { get; set; }
        public Nullable<decimal> CategorySales { get; set; }
    }
}

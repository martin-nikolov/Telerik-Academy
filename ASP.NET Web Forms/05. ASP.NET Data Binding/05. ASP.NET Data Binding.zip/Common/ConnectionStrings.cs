﻿namespace Common
{
    using System;
    using System.Linq;
    
    public static class ConnectionStrings
    {
        public const string DefaultConnection = @"Data Source=.\sqlexpress;Initial Catalog=Northwind;Integrated Security=True;MultipleActiveResultSets=True";
    }
}
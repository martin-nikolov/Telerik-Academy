Change connection string in Settings.settings or App.config file in each project.

You must install packages:
    - MySql.Data.6.8.3
    - System.Data.SQLite.Core.1.0.92.0
Change connection string in Settings.settings or App.config file in each project.

Task 10: Find folders with names "x86" and "x64" in the project directory and move them into "bin/Debug"

You must install packages:
    - MySql.Data.6.8.3
    - System.Data.SQLite.Core.1.0.92.0
﻿/*
 * 8. By inheriting the Employee entity class create a class which
 * allows employees to access their corresponding territories as
 * property of type EntitySet<T>.
 */

namespace EntityFramework.ConsoleClient
{
    using System;
    using System.Linq;

    class EmployeeExtendedTest
    {
        static void Main()
        {
            // EntitySet<T> is not available in EF 5/6 versions.
        }
    }
}
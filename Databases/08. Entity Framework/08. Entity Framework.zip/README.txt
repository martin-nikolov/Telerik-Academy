Change connection string in Settings.settings or App.config file in each project.

You must install packages:
    - EntityFramework.6.1.0
Change connection string in ConnectionStrings.settings or App.config file in each project.

You must install packages:
    - EntityFramework.6.1.0
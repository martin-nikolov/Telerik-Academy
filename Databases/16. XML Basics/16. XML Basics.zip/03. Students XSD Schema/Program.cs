﻿namespace _03.Students__XSD_Schema
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Program
    {
        internal static void Main()
        {
        }
    }
}
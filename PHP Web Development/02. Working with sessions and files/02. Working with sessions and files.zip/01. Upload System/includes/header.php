<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo $title ?></title>
    <meta charset="UTF-8">
</head>
<body>


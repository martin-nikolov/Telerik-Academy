<!DOCTYPE html>
<html>
<head>
    <title><?php echo $title ?></title>
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="includes/styles.css" />
</head>
<body>


﻿namespace AcademyEcosystem
{
    using System;
    using System.Linq;

    public enum AnimalState
    {
        Sleeping,
        Awake
    }
}
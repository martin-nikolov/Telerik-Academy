﻿namespace AcademyEcosystem
{
    using System;
    using System.Linq;

    public class Bush : Plant
    {
        public Bush(Point location)
            : base(location, 4)
        {
        }
    }
}
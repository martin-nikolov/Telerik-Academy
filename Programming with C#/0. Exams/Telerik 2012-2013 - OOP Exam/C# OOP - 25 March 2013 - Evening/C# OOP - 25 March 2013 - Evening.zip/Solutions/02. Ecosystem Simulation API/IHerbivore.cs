﻿namespace AcademyEcosystem
{
    using System;
    using System.Linq;

    public interface IHerbivore
    {
        int EatPlant(Plant plant);
    }
}
﻿namespace AcademyEcosystem
{
    using System;
    using System.Linq;

    public class Tree : Plant
    {
        public Tree(Point location)
            : base(location, 15)
        {
        }
    }
}
﻿namespace AcademyRPG
{
    using System;
    using System.Linq;

    public enum ResourceType
    {
        Lumber,
        Stone,
        Gold,
    }
}
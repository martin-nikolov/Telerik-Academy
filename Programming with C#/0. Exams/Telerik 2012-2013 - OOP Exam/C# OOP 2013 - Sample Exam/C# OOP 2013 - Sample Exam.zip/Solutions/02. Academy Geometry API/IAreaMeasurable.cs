namespace AcademyGeometry
{
    public interface IAreaMeasurable
    {
        double GetArea();
    }
}
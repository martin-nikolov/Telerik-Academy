namespace AcademyGeometry
{
    public interface IFlat
    {
        Vector3D GetNormal();
    }
}
namespace AcademyGeometry
{
    public interface ILengthMeasurable
    {
        double GetLength();
    }
}
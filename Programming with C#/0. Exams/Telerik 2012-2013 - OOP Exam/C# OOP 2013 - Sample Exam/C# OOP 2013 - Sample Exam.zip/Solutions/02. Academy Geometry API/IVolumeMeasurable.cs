namespace AcademyGeometry
{
    public interface IVolumeMeasurable
    {
        double GetVolume();
    }
}
namespace Computers.Models.Enumerations
{
    public enum ComputerType
    {
        PersonalComputer,
        Laptop,
        Server,
    }
}
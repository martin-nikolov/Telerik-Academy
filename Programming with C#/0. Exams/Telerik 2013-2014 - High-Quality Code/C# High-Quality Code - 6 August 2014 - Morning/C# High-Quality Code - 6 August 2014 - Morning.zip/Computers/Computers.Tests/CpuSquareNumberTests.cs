﻿namespace Computers.Tests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class CpuSquareNumberTests
    {
        [TestMethod]
        public void CreateBatteryInitiallyShouldReturn50Percents()
        {
            // var cpu = new Cpu32Bits(4, null);
            // var generatedNumber = cpu.GenerateRandomNumber(1, 100);
            // Assert.AreEqual(customNumber, generatedNumber);
        }
    }
}
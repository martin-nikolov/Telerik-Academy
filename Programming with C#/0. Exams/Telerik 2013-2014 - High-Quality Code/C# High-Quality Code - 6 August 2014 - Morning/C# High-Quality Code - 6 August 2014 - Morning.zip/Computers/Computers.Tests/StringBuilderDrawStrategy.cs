﻿namespace Computers.Tests
{
    using System;
    using System.Linq;
    using Computers.Models.Contracts;

    class StringBuilderDrawStrategy : IDrawStrategy
    {
        public void DrawColorful(string text)
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }

        public void DrawMonochrome(string text)
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }
    }
}
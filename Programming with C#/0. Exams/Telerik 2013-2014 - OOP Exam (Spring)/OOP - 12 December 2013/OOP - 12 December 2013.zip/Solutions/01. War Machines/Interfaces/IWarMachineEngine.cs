namespace WarMachines.Interfaces
{
    public interface IWarMachineEngine
    {
        void Start();
    }
}
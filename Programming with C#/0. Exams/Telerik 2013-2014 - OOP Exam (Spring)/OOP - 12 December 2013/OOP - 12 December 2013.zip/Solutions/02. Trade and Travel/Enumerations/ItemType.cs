﻿using System;
using System.Linq;

namespace TradeAndTravel.Enumerations
{
    public enum ItemType
    {
        Weapon,
        Armor,
        Wood,
        Iron,
    }
}
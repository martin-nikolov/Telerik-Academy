﻿using System;
using System.Linq;

namespace TradeAndTravel.Enumerations
{
    public enum LocationType
    {
        Mine,
        Town,
        Forest,
    }
}
﻿namespace ForumSystem.Common
{
    using System;
    using System.Linq;
    
    public class ConnectionStrings
    {
        public const string DefaultConnection = @"Data Source=.\sqlexpress;Initial Catalog=ForumSystem;Integrated Security=True";
    }
}
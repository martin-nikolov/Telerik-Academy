﻿namespace BullAndCows.Data
{
    using System;
    using System.Data.Entity;
    using BullAndCows.Data.Contracts;
    using BullAndCows.Data.Migrations;
    using BullsAndCows.Common;
    using BullsAndCows.Models;
    using Microsoft.AspNet.Identity.EntityFramework;

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>, IBullsAndCowsDbContext
    {
        public ApplicationDbContext()
            : base(ConnectionStrings.BullsAndCowsConnectionString, throwIfV1Schema: false)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<ApplicationDbContext, Configuration>());
        }

        public IDbSet<Game> Games { get; set; }

        public IDbSet<Guess> Guesses { get; set; }

        public IDbSet<Score> Scores { get; set; }

        public IDbSet<Notification> Notification { get; set; }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }

        public IDbSet<T> Set<T>() where T : class
        {
            return base.Set<T>();
        }

        public void SaveChanges()
        {
            base.SaveChanges();
        }
    }
}
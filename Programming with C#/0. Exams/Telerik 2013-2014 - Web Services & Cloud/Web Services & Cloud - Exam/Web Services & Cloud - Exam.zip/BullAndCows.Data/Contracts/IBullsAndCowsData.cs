﻿namespace BullAndCows.Data.Contracts
{
    using System;
    using System.Linq;
    using BullsAndCows.Models;

    public interface IBullsAndCowsData : IDisposable
    {
        IGenericRepository<Game> Games { get; }

        IGenericRepository<Guess> Guesses { get; }

        IGenericRepository<Score> Scores { get; }

        IGenericRepository<ApplicationUser> Users { get; }

        IGenericRepository<Notification> Notification { get; }

        int SaveChanges();
    }
}
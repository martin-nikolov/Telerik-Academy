﻿namespace BullAndCows.Data.Contracts
{
    using System;
    using System.Data.Entity;
    using System.Linq;
    using BullsAndCows.Models;

    public interface IBullsAndCowsDbContext : IDbContext
    {
        IDbSet<Game> Games { get; set; }

        IDbSet<Guess> Guesses { get; set; }

        IDbSet<Score> Scores { get; set; }

        IDbSet<ApplicationUser> Users { get; set; }

        IDbSet<Notification> Notification { get; set; }
    }
}
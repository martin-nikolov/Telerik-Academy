﻿namespace BullsAndCows.ConsoleClient
{
    using System;
    using System.Linq;

    public class BullsAndCowsConsoleClient
    {
        internal static void Main()
        {
        }
    }
}
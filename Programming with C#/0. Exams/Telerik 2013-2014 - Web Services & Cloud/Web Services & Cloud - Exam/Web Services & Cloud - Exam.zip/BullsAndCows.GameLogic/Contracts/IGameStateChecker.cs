namespace BullsAndCows.GameLogic.Contracts
{
    public interface IGameStateChecker
    {
        int GetNumberOfCows(int number, int numberToGuess);

        int GetNumberOfBulls(int number, int numberToGuess);

        bool IsGuessNumberValid(int number);
    }
}
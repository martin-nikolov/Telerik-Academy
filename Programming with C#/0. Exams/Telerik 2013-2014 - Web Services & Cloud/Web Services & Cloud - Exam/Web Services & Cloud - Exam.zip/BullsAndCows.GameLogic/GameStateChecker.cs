﻿namespace BullsAndCows.GameLogic
{
    using System;
    using System.Linq;
    using BullsAndCows.GameLogic.Contracts;
    
    public class GameStateChecker : IGameStateChecker
    {
        private const int NumberLength = 4;

        public int GetNumberOfCows(int number, int numberToGuess)
        {
            var numChars = this.NumberToCharArray(number);
            var numToGuessChars = this.NumberToCharArray(numberToGuess);

            var guessedDigits = 0;
            for (int i = 0; i < numChars.Length; i++)
            {
                for (int j = 0; j < numToGuessChars.Length; j++)
                {
                    if (i == j)
                    {
                        continue;
                    }

                    if (numChars[i] == numToGuessChars[j])
                    {
                        guessedDigits++;
                        break;
                    }
                }
            }

            return guessedDigits;
        }

        public int GetNumberOfBulls(int number, int numberToGuess)
        {
            var numChars = this.NumberToCharArray(number);
            var numToGuessChars = this.NumberToCharArray(numberToGuess);

            var guessedDigits = 0;
            for (int i = 0; i < numChars.Length; i++)
            {
                if (numChars[i] == numToGuessChars[i])
                {
                    guessedDigits++;
                }
            }

            return guessedDigits;
        }

        /// <summary>
        /// Number cannot starts with 0 and must be in range [1000; 9999]
        /// </summary>
        public bool IsGuessNumberValid(int number)
        {
            if (number < 1000 || number > 9999)
            {
                return false;
            }

            var uniqueSymbols = number.ToString().ToCharArray().Distinct();
            if (uniqueSymbols.Count() != NumberLength)
            {
                return false;
            }

            return true;
        }

        private char[] NumberToCharArray(int number)
        {
            return number.ToString().ToCharArray();
        }
    }
}
﻿namespace BullsAndCows.IntegrationTests
{
    using System;
    using System.Net;
    using BullAndCows.Data.Contracts;
    using BullsAndCows.IntegrationTests.Server;
    using BullsAndCows.Models;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Telerik.JustMock;

    [TestClass]
    public class ScoresTests
    {
        private const string InMemoryServerUrl = "http://localhost:8888";

        [TestMethod]
        public void GetAllShouldReturnStatus200AndNonEmptyContent()
        {
            var bugLoggerData = this.MockUnitOfWorkForActionAll();

            var server = new InMemoryHttpServer<Score>(InMemoryServerUrl, bugLoggerData);
            var response = server.CreateGetRequest("/api/Scores/");

            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.IsNotNull(response.Content);
        }

        private IBullsAndCowsData MockUnitOfWorkForActionAll()
        {
            var scoreFakeRepository = Mock.Create<IGenericRepository<Score>>();
            var bullsAndCowsData = Mock.Create<IBullsAndCowsData>();
            Mock.Arrange(() => bullsAndCowsData.Scores)
                .Returns(() => scoreFakeRepository);
            return bullsAndCowsData;
        }
    }
}
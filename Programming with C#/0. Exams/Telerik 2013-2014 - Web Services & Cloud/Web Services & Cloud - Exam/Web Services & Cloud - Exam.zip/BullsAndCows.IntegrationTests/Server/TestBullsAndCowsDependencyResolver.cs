﻿namespace BullsAndCows.IntegrationTests.Server
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Http.Dependencies;
    using BullAndCows.Data.Contracts;
    using BullsAndCows.Services.Controllers;

    public class TestBullsAndCowsDependencyResolver<T> : IDependencyResolver
    {
        private IBullsAndCowsData bullsAndCowsData;

        public IBullsAndCowsData BullsAndCowsData
        {
            get
            {
                return this.bullsAndCowsData;
            }
            set
            {
                this.bullsAndCowsData = value;
            }
        }
   
        public IDependencyScope BeginScope()
        {
            return this;
        }

        public object GetService(Type serviceType)
        {
            if (serviceType == typeof(ScoresController))
            {
                return new ScoresController();
            }

            return null;
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            return new List<object>();
        }

        public void Dispose()
        {
        }
    }
}
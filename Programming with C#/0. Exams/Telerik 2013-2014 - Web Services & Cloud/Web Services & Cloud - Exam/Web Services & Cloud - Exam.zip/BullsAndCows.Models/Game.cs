﻿namespace BullsAndCows.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;

    /// <summary>
    /// Red player - creator of the game
    /// Blue player - the player joined in the game
    /// </summary>
    public class Game
    {
        private ICollection<Guess> guesses;

        public Game()
        {
            this.GameState = GameState.WaitingForOpponent;
            this.guesses = new HashSet<Guess>();
        }

        public int GameId { get; set; }

        [Required]
        public string Name { get; set; }

        public DateTime DateCreated { get; set; }

        public GameState GameState { get; set; }

        [Required]
        public string RedPlayerId { get; set; }

        public virtual ApplicationUser RedPlayer { get; set; }

        public int RedPlayerNumber { get; set; }

        public string BluePlayerId { get; set; }

        public virtual ApplicationUser BluePlayer { get; set; }

        public int? BluePlayerNumber { get; set; }

        public virtual ICollection<Guess> Guesses
        {
            get
            {
                return this.guesses;
            }
            set
            {
                this.guesses = value;
            }
        }
    }
}
﻿namespace BullsAndCows.Models
{
    using System;
    using System.Linq;

    public enum GameState
    {
        WaitingForOpponent, // Do not have a blue player
        TurnRedPlayer,
        TurnBluePlayer,
        WonByRedPlayer,
        WonByBluePlayer
    }
}
﻿namespace BullsAndCows.Models
{
    using System;
    using System.Linq;

    public enum NotificationType
    {
        YourTurn,
        GameLost,
        GameWon,
        GameJoined
    }
}
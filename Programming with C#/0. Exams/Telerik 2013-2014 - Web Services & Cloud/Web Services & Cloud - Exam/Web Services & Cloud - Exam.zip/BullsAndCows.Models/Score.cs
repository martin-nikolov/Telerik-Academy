﻿namespace BullsAndCows.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;

    public class Score
    {
        [Key]
        public int ScoreId { get; set; }

        public string UserId { get; set; }

        public virtual ApplicationUser User { get; set; }

        public int GameId { get; set; }

        public virtual Game Game { get; set; }

        public bool IsWin { get; set; }
    }
}
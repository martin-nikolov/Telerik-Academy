﻿namespace BullsAndCows.Services.Controllers
{
    using System;
    using System.Linq;
    using System.Web.Http;
    using BullAndCows.Data.Contracts;
    using BullAndCows.Data.UnitOfWork;
    using BullsAndCows.Services.Infrastructure;

    public class BaseApiController : ApiController
    {
        private IBullsAndCowsData bullsAndCowsData;
        private IUserInfoProvider userInfoProvider;

        public BaseApiController()
            : this(new BullsAndCowsData())
        {
            this.UserInfoProvider = new AspNetUserInfoProvider();
        }

        public BaseApiController(IBullsAndCowsData bullsAndCowsData)
        {
            this.BullsAndCowsData = bullsAndCowsData;
        }

        protected IUserInfoProvider UserInfoProvider
        {
            get
            {
                return this.userInfoProvider;
            }
            set
            {
                this.userInfoProvider = value;
            }
        }

        protected IBullsAndCowsData BullsAndCowsData
        {
            get
            {
                return this.bullsAndCowsData;
            }
            set
            {
                this.bullsAndCowsData = value;
            }
        }
    }
}
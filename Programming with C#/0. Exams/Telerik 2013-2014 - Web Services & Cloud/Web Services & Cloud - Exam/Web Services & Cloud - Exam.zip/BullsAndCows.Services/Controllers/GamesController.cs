﻿namespace BullsAndCows.Services.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Http;
    using BullsAndCows.Common;
    using BullsAndCows.GameLogic;
    using BullsAndCows.GameLogic.Contracts;
    using BullsAndCows.Models;
    using BullsAndCows.Services.Models;

    public class GamesController : BaseApiController
    {
        private const string NoBluePlayerYetMessage = "No blue player yet";
        private const int DefaultPage = 0;
        private const int DefaultPageSize = 10;

        // TODO: Move - Dependency inversion
        private IGameStateChecker gameStateChecker = new GameStateChecker();

        public GamesController()
            : base()
        {
        }

        [Authorize]
        public IHttpActionResult Get(int id)
        {
            var game = this.BullsAndCowsData.Games.Find(id);
            if (game == null)
            {
                return this.BadRequest(string.Format("Game with id={0} is finished or does not exists!", id));
            }
            else if (game.GameState == GameState.WonByBluePlayer ||
                     game.GameState == GameState.WonByRedPlayer ||
                     game.GameState == GameState.WaitingForOpponent)
            {
                return this.BadRequest("The game state does not allow you to see game details!");
            }

            var userId = this.UserInfoProvider.GetUserId();
            bool isPlayerPartOfThisGame = game.RedPlayerId == userId || game.BluePlayerId == userId;
            if (!isPlayerPartOfThisGame)
            {
                return this.BadRequest("You are not part of this game!");
            }

            var gameDetailsModel = GameDetailsModel.AsGameDetailsModel(game, userId);
            return this.Ok(gameDetailsModel);
        }
 
        public IHttpActionResult Get([FromUri]
                                     int? p = 0)
        {
            IList<GameInfoModel> games;

            if (this.UserInfoProvider.IsUserAuthenticated())
            {
                var userId = this.UserInfoProvider.GetUserId();
                games = this.GetGamesForAuthorizedUser(userId, p);
                return this.Ok(games);
            }
            else
            {
                games = this.GetGamesForNotAuthorizedUser(p);
                return this.Ok(games);
            }
        }

        [HttpPost]
        [Authorize]
        public IHttpActionResult Guess(int id, int number)
        {
            bool isNumberValid = this.gameStateChecker.IsGuessNumberValid(number);
            if (!isNumberValid)
            {
                return this.BadRequest("Invalid number.");
            }

            var game = this.BullsAndCowsData.Games.Find(id);
            if (game == null)
            {
                return this.BadRequest(string.Format("Game with id={0} does not exists!", id));
            }

            var userId = this.UserInfoProvider.GetUserId();
            bool isPlayerPartOfGame = game.RedPlayerId == userId || game.BluePlayerId == userId;
            if (!isPlayerPartOfGame)
            {
                return this.BadRequest("You are not part of this game!");
            }

            if (game.GameState == GameState.WonByBluePlayer || game.GameState == GameState.WonByRedPlayer)
            {
                return this.BadRequest(string.Format("Game with id={0} is finished!", id));
            }

            if (game.GameState == GameState.TurnBluePlayer && game.BluePlayerId != userId ||
                game.GameState == GameState.TurnRedPlayer && game.RedPlayerId != userId)
            {
                return this.BadRequest("It's not your turn!");
            }

            int numberToGuess = this.GetNumberToGuess(game, userId);

            var guess = new Guess()
            {
                UserId = userId,
                GameId = id,
                Number = number,
                DateMade = DateTime.Now,
                BullsCount = this.gameStateChecker.GetNumberOfBulls(number, numberToGuess),
                CowsCount = this.gameStateChecker.GetNumberOfCows(number, numberToGuess)
            };

            if (guess.BullsCount == 4)
            {
                game.GameState = this.GetGameWonByStatus(game, userId);
            }
            else
            {
                game.GameState = this.ChangeTurn(game);
            }

            game.Guesses.Add(guess);
            this.BullsAndCowsData.SaveChanges();

            var guessResultModel = GuessModel.AsGuessModel(guess);
            guessResultModel.Id = guess.GuessId;
            guessResultModel.Username = this.UserInfoProvider.GetUsername();
            return this.Ok(guessResultModel);
        }
 
        [HttpPut]
        [Authorize]
        public IHttpActionResult Join(int id, int number)
        {
            bool isNumberValid = this.gameStateChecker.IsGuessNumberValid(number);
            if (!isNumberValid)
            {
                return this.BadRequest("Invalid number.");
            }

            var game = this.GetNotFinishedGameById(id);
            if (game == null)
            {
                return this.BadRequest(string.Format("Game with id={0} is finished or does not exists!", id));
            }

            var userId = this.UserInfoProvider.GetUserId();
            bool isSamePlayer = game.RedPlayerId == userId || game.BluePlayerId == userId;
            if (isSamePlayer)
            {
                return this.BadRequest("Cannot join in game that you are already part of!");
            }

            game.BluePlayerId = userId;
            game.BluePlayerNumber = number;
            game.GameState = this.GetRandomStatus();

            this.SetNotification(string.Format("{0} joined your game \"{1}\"", this.GetUsernameById(userId), game.Name),
                NotificationType.GameJoined, game.GameId, game.RedPlayerId);

            this.NotifyPlayerInTurn(game);

            this.BullsAndCowsData.SaveChanges();

            var joinGameResult = new JoinGameResult(string.Format("You joined game \"{0}\"", game.Name));
            return this.Ok(joinGameResult);
        }
 
        [Authorize]
        public IHttpActionResult Create(CreateGameModel createGameModel)
        {
            if (!this.ModelState.IsValid || createGameModel == null)
            {
                return this.BadRequest("Invalid creational game model.");
            }

            bool isNumberValid = this.gameStateChecker.IsGuessNumberValid(createGameModel.Number);
            if (!isNumberValid)
            {
                return this.BadRequest("Invalid number.");
            }

            var game = new Game()
            {
                Name = createGameModel.Name,
                RedPlayerId = this.UserInfoProvider.GetUserId(),
                RedPlayerNumber = createGameModel.Number,
                GameState = GameState.WaitingForOpponent,
                DateCreated = DateTime.Now
            };

            this.BullsAndCowsData.Games.Add(game);
            this.BullsAndCowsData.SaveChanges();

            var response = new GameInfoModel
            {
                Id = game.GameId,
                Name = game.Name,
                Blue = NoBluePlayerYetMessage,
                Red = game.RedPlayerId,
                GameState = game.GameState,
                DateCreated = game.DateCreated
            };

            return this.Ok(response);
        }

        private void NotifyPlayerInTurn(Game game)
        {
            if (game.GameState == GameState.TurnRedPlayer)
            {
                this.SetNotification(string.Format("It is your turn in game \"{0}\"", game.Name),
                    NotificationType.YourTurn, game.GameId, game.RedPlayerId);
            }
            else
            {
                this.SetNotification(string.Format("It is your turn in game \"{0}\"", game.Name),
                    NotificationType.YourTurn, game.GameId, game.BluePlayerId);
            }
        }
 
        private GameState GetGameWonByStatus(Game game, string userId)
        {
            if (game.BluePlayerId == userId)
            {
                this.SetNotification(string.Format("You beat {0} in game \"{1}\"", this.GetUsernameById(game.RedPlayerId), game.Name),
                    NotificationType.GameWon, game.GameId, game.BluePlayerId);
                this.SetNotification(string.Format("{0} beat you in game \"{1}\"", this.GetUsernameById(game.BluePlayerId), game.Name),
                    NotificationType.GameLost, game.GameId, game.RedPlayerId);
                this.AddToScore(game.BluePlayerId, game.RedPlayerId, game.GameId);
                return GameState.WonByBluePlayer;
            }
            else
            {
                this.SetNotification(string.Format("You beat {0} in game \"{1}\"", this.GetUsernameById(game.BluePlayerId), game.Name),
                    NotificationType.GameWon, game.GameId, game.RedPlayerId);
                this.SetNotification(string.Format("{0} beat you in game \"{1}\"", this.GetUsernameById(game.RedPlayerId), game.Name),
                    NotificationType.GameLost, game.GameId, game.BluePlayerId);
                this.AddToScore(game.RedPlayerId, game.BluePlayerId, game.GameId);
                return GameState.WonByRedPlayer;
            }
        }

        private void SetNotification(string message, NotificationType type, int gameId, string userId)
        {
            this.BullsAndCowsData.Notification.Add(new Notification()
            {
                UserId = userId,
                Message = message,
                NotificationType = type,
                DateCreated = DateTime.Now,
                GameId = gameId
            });
        }
 
        private void AddToScore(string blueId, string redId, int gameId)
        {
            this.BullsAndCowsData.Scores.Add(new Score()
            {
                IsWin = true,
                UserId = blueId,
                GameId = gameId
            });

            this.BullsAndCowsData.Scores.Add(new Score()
            {
                IsWin = false,
                UserId = redId,
                GameId = gameId
            });
        }

        private int GetNumberToGuess(Game game, string userId)
        {
            int numberToGuess = 0;

            if (game.RedPlayerId == userId)
            {
                numberToGuess = game.BluePlayerNumber.Value;
            }
            else
            {
                numberToGuess = game.RedPlayerNumber;
            }

            return numberToGuess;
        }

        private GameState ChangeTurn(Game game)
        {
            if (game.GameState == GameState.TurnBluePlayer)
            {
                this.SetNotification(string.Format("It is your turn in game \"{0}\"", game.Name),
                    NotificationType.YourTurn, game.GameId, game.RedPlayerId);
                return GameState.TurnRedPlayer;
            }
            else
            {
                this.SetNotification(string.Format("It is your turn in game \"{0}\"", game.Name),
                    NotificationType.YourTurn, game.GameId, game.BluePlayerId);
                return GameState.TurnBluePlayer;
            }
        }

        private GameState GetRandomStatus()
        {
            if (RandomDataGenerator.Instance.GetChance(50))
            {
                return GameState.TurnBluePlayer;
            }
            else
            {
                return GameState.TurnRedPlayer;
            }
        }

        private Game GetNotFinishedGameById(int id)
        {
            var game = this.BullsAndCowsData.Games
                           .All()
                           .Where(g => g.GameId == id && g.GameState == GameState.WaitingForOpponent)
                           .FirstOrDefault();
            return game;
        }

        private string GetUsernameById(string id)
        {
            return this.BullsAndCowsData.Users
                       .All()
                       .First(u => u.Id == id).UserName;
        }

        private IList<GameInfoModel> GetGamesForNotAuthorizedUser(int? page = 0)
        {
            var onPage = page.HasValue ? page.Value : DefaultPage;
            var games = this.BullsAndCowsData.Games
                            .All()
                            .Where(g => g.GameState == GameState.WaitingForOpponent)
                            .Select(GameInfoModel.FromGame)
                            .OrderBy(g => g.Name)
                            .ThenBy(g => g.DateCreated)
                            .ThenBy(g => g.Red)
                            .Skip(onPage * DefaultPageSize)
                            .Take(DefaultPageSize)
                            .ToList();
            return games;
        }

        private IList<GameInfoModel> GetGamesForAuthorizedUser(string userId, int? page = 0)
        {
            var onPage = page.HasValue ? page.Value : DefaultPage;
            var games = this.BullsAndCowsData.Games
                            .All()
                            .Where(g => (g.BluePlayerId == userId || g.RedPlayerId == userId) &&
                                        g.GameState != GameState.WonByBluePlayer &&
                                        g.GameState != GameState.WonByRedPlayer || 
                                        g.GameState == GameState.WaitingForOpponent)
                            .Select(GameInfoModel.FromGame)
                            .OrderBy(g => g.Name)
                            .ThenBy(g => g.DateCreated)
                            .ThenBy(g => g.Red)
                            .Skip(onPage * DefaultPageSize)
                            .Take(DefaultPageSize)
                            .ToList();
            return games;
        }
    }
}
﻿namespace BullsAndCows.Services.Controllers
{
    using System;
    using System.Linq;
    using System.Web.Http;
    using BullsAndCows.Models;
    using BullsAndCows.Services.Models;

    public class NotificationsController : BaseApiController
    {
        private const int DefaultPageSize = 10;

        public NotificationsController()
            : base()
        {
        }

        [Authorize]
        public IHttpActionResult Get([FromUri]
                                     int? page = 0)
        {
            var userId = this.UserInfoProvider.GetUserId();
            var notifications = this.BullsAndCowsData.Notification
                                    .All()
                                    .Where(a => a.UserId == userId)
                                    .OrderByDescending(n => n.DateCreated)
                                    .Select(NotificationModel.FromNotification)
                                    .Skip(page.Value * DefaultPageSize)
                                    .Take(DefaultPageSize);

            return this.Ok(notifications);
        }

        [Authorize]
        [HttpGet]
        public IHttpActionResult GetNext()
        {
            var userId = this.UserInfoProvider.GetUserId();
            var notification = this.BullsAndCowsData.Notification
                                   .All()
                                   .Where(a => a.UserId == userId && a.NotificationState == NotificationState.Unread)
                                   .OrderBy(n => n.DateCreated);

            var firstNotification = notification.FirstOrDefault();
            if (firstNotification == null)
            {
                return this.BadRequest("No notifications.");
            }

            var model = notification.Select(NotificationModel.FromNotification)
                                    .FirstOrDefault();

            firstNotification.NotificationState = NotificationState.Read;
            this.BullsAndCowsData.SaveChanges();

            return this.Ok(model);
        }
    }
}
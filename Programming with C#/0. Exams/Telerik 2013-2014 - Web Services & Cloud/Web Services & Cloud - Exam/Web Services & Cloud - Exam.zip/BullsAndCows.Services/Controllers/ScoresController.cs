﻿namespace BullsAndCows.Services.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Http;
    using BullsAndCows.Services.Models;

    public class ScoresController : BaseApiController
    {
        public ScoresController()
            : base()
        {
        }

        public IHttpActionResult Get()
        {
            var users = this.BullsAndCowsData.Users.All().Select(u => new { Id = u.Id, UserName = u.UserName }).ToList();
            var usersRanks = new List<ScoreModel>();

            foreach (var user in users)
            {
                var wins = this.BullsAndCowsData.Scores.All().Count(s => s.UserId == user.Id && s.IsWin);
                var loses = this.BullsAndCowsData.Scores.All().Count(s => s.UserId == user.Id && !s.IsWin);
                usersRanks.Add(new ScoreModel()
                {
                    Username = user.UserName,
                    Rank = 100 * wins + 15 * loses
                });
            }

            usersRanks = usersRanks.OrderByDescending(a => a.Rank)
                                   .ThenBy(a => a.Username)
                                   .Take(10)
                                   .ToList();

            return this.Ok(usersRanks);
        }
    }
}
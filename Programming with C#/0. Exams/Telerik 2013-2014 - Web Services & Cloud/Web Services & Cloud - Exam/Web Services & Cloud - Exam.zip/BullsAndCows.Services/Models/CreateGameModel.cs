﻿namespace BullsAndCows.Services.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;

    public class CreateGameModel
    {
        [Required]
        public string Name { get; set; }

        public int Number { get; set; }
    }
}
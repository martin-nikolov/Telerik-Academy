﻿namespace BullsAndCows.Services.Models
{
    using System;
    using System.Linq;

    public class JoinGameResult
    {
        public JoinGameResult(string result)
        {
            this.Result = result;
        }

        public string Result { get; set; }
    }
}
﻿namespace BullsAndCows.Services.Models
{
    using System;
    using System.Linq;

    public class ScoreModel
    {
        public string Username { get; set; }

        public int Rank { get; set; }
    }
}
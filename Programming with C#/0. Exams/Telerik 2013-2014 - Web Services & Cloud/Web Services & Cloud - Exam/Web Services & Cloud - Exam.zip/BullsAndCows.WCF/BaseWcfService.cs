﻿namespace BullsAndCows.WCF
{
    using System;
    using System.Linq;
    using BullAndCows.Data.Contracts;
    using BullAndCows.Data.UnitOfWork;

    public class BaseWcfService
    {
        private IBullsAndCowsData bullsAndCowsData;

        public BaseWcfService()
            : this(new BullsAndCowsData())
        {
        }

        public BaseWcfService(IBullsAndCowsData bullsAndCowsData)
        {
            this.BullsAndCowsData = bullsAndCowsData;
        }
     
        protected IBullsAndCowsData BullsAndCowsData
        {
            get
            {
                return this.bullsAndCowsData;
            }
            set
            {
                this.bullsAndCowsData = value;
            }
        }
    }
}
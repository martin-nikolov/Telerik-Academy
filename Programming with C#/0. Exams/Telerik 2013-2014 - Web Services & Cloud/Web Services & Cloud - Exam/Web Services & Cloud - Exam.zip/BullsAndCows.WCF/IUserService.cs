﻿namespace BullsAndCows.WCF
{
    using System;
    using System.Linq;
    using System.ServiceModel;
    using BullsAndCows.WCF.Models;

    [ServiceContract]
    public interface IUsersService
    {
        [OperationContract]
        IQueryable<UserModel> Get(int? page);
    }
}
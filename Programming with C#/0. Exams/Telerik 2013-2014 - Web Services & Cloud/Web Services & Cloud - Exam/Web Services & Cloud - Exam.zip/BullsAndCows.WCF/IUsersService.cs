﻿namespace BullsAndCows.WCF
{
    using System;
    using System.Linq;
    using System.ServiceModel;
    using System.ServiceModel.Web;
    using BullsAndCows.WCF.Models;

    [ServiceContract]
    public interface IUsersService
    {
        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Bare, ResponseFormat = WebMessageFormat.Json, UriTemplate = "users?page={page}")]
        IQueryable<UserModel> Get(int page);

        [OperationContract]
        [WebInvoke(Method = "GET", BodyStyle = WebMessageBodyStyle.Bare, ResponseFormat = WebMessageFormat.Json, UriTemplate = "users/{id}")]
        UserDetails GetDetails(string id);
    }
}
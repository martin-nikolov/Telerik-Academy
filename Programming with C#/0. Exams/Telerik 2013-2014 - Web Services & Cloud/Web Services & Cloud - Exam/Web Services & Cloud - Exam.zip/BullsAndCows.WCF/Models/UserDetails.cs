﻿namespace BullsAndCows.WCF.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using BullsAndCows.Models;

    public class UserDetails
    {
        public static Expression<Func<ApplicationUser, UserDetails>> FromUser
        {
            get
            {
                return user => new UserDetails
                {
                    Id = user.Id,
                    Username = user.UserName
                };
            }
        }

        public string Id { get; set; }

        public int Losses { get; set; }

        public int Rank { get; set; }

        public int Wins { get; set; }

        public string Username { get; set; }

        public static UserDetails AsUsersDetails(ApplicationUser user)
        {
            var userInCollection = new List<ApplicationUser> { user };
            var userDetails = userInCollection.AsQueryable()
                                              .Select(UserDetails.FromUser)
                                              .First();

            userDetails.Wins = user.Scores.Count(s => s.IsWin);
            userDetails.Losses = user.Scores.Count(s => !s.IsWin);
            userDetails.Rank = 100 * userDetails.Wins + 15 * userDetails.Losses;
            return userDetails;
        }
    }
}
﻿namespace BullsAndCows.WCF.Models
{
    using System;
    using System.Linq;
    using System.Linq.Expressions;
    using BullsAndCows.Models;

    public class UserModel
    {
        public static Expression<Func<ApplicationUser, UserModel>> FromUser
        {
            get
            {
                return user => new UserModel
                {
                    Id = user.Id,
                    Username = user.UserName
                };
            }
        }

        public string Id { get; set; }

        public string Username { get; set; }
    }
}
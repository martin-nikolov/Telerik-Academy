﻿namespace BullsAndCows.WCF
{
    using System;
    using System.Linq;
    using BullsAndCows.WCF.Models;

    public class UsersService : BaseWcfService, IUsersService
    {
        private const int DefaultPageSize = 10;

        /// <summary>
        /// Access it -> http://localhost:5348/UsersService.svc/users?page=0 (change port)
        /// </summary>
        public IQueryable<UserModel> Get(int page)
        {
            return this.BullsAndCowsData.Users
                       .All()
                       .OrderBy(u => u.UserName)
                       .Skip(page * DefaultPageSize)
                       .Take(DefaultPageSize)
                       .Select(UserModel.FromUser);
        }

        public UserDetails GetDetails(string id)
        {
            var user = this.BullsAndCowsData.Users
                           .All()
                           .Where(u => u.Id == id)
                           .FirstOrDefault();

            if (user == null)
            {
                throw new ArgumentException(string.Format("User with id={0} does not exists", id));
            }

            return UserDetails.AsUsersDetails(user);
        }
    }
}
Change the connection string in BullsAndCows.Common/ConnectionStrings.cs

За заявките като http://localhost:XXXXX/api/games/{ID}/guess, вместо да се подава в Request Body-то: {"number": "1234"}, се подава по следният начин: http://localhost:XXXXX/api/games/{ID}/guess?number={number}. Другите заявки са по същият начин (освен Registration и Login)

Create a new game - работи през Body

Регистрацията става чрез Email + Password + ConfirmPassword, вместо Username + Password + ...
#include <iostream>
using namespace std;
int main ()
{
    long long int a[11000], k, n, s = 0, i, j, minx, maxx;;
    cin >> n >> k;
    for ( i = 0; i < n; i++ )
    {
        cin >> a[i];
        s += a[i];
    }
    for ( i = 0; i < k; i++ )
    for ( j = 0; j < n; j++ ) a[j] = (s - a[j]);
    minx = maxx = a[0];
    for ( i = 1; i < n; i++ )
    {
        if ( a[i] < minx ) minx = a[i];
        if ( a[i] > maxx ) maxx = a[i];
    }
    cout << maxx - minx << endl;
    return 0;
}


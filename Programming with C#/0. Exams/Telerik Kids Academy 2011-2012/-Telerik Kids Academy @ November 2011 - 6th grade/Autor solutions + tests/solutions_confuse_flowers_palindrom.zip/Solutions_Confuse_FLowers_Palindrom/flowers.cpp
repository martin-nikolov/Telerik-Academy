#include <iostream>
using namespace std;
int main()
{
    int a,b,c,x,i,j,maxm = 0, maxbr = 0;
    cin >> a >> b >> c;
    for ( i = 0; i <= c/a; i++ )
    for ( j = 0; j <= c/b; j++ )
        if ( ( i + j ) > maxbr )
        {
            if( (i*a + j*b) <= c )
             {
                 maxm = (i*a + j*b);
                 maxbr = i+j;
               //  cout << maxbr << endl;
             }
        }
    cout << maxm << endl;
    return 0;
}
#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

string s1, s2, s3;

void read ()
{
    cin >> s1;
}

void solve ()
{
    int sz, i;
    s2 = ""; s3 = "";
    sz = s1.size ();
    for ( i = 0; i < sz; i++ ) if ( s1[i] != 'a' && s1[i] != 'o' && s1[i] != 'e' && s1[i] != 'i' ) s2+=s1[i];
    s3 = s2;
    reverse ( s3.begin(), s3.end() );
    if ( s3 == s2 ) cout << "YES\n";
    else cout << "NO\n";
}

int main ()
{
    int tests;
    cin >> tests;
    while ( tests -- )
    {
        read ();
        solve ();
    }
    return 0;
}
#include<iostream>
using namespace std;
int main ()
{
    char ch;
    int sum=0,l=0;
    cin.get(ch);
    if(ch>='0'&&ch<='9'){sum+=(ch-'0');l=1;}
    cin.get(ch);
    if(ch>='0'&&ch<='9'){sum+=(ch-'0');l=1;}
    cin.get(ch);
    if(ch>='0'&&ch<='9'){sum+=(ch-'0');l=1;}
    cin.get(ch);
    if(ch>='0'&&ch<='9'){sum+=(ch-'0');l=1;}
    cin.get(ch);
    if(ch>='0'&&ch<='9'){sum+=(ch-'0');l=1;}
    cin.get(ch);
    if(ch>='0'&&ch<='9'){sum+=(ch-'0');l=1;}
    cin.get(ch);
    if(ch>='0'&&ch<='9'){sum+=(ch-'0');l=1;}
    if(l)cout<<sum<<endl;
    else cout<<"-1"<<endl;
    return 0;
}


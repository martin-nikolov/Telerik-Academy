#include<iostream>
#include<cmath>
using namespace std;
int main ()
{
    int a,b,c,d,h,ans=0,pom;
    cin>>a>>b>>c>>d>>h;
    if(a>b)
    {
        pom=a; a=b; b=pom;
    }
    if(b>c)
    {
        pom=b; b=c; c=pom;
    }
    if(a>b)
    {
        pom=a; a=b; b=pom;
    }
    if(d>h)
    {
        pom=d; d=h; h=pom;
    }
    ans=(h+abs(h-c)+(2*d)+a+b);
    cout<<ans<<endl;
    return 0;
}
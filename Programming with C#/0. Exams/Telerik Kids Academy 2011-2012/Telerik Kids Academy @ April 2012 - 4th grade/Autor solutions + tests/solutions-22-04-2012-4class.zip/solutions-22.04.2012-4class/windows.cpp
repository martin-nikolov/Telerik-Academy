#include<iostream>
using namespace std;
int main ()
{
    int n,c,x,y,is_broken,ans=0,i;
    cin>>n>>c;
    for(i=1;i<=n;i++)
    {
        cin>>x>>y>>is_broken;
        if(is_broken) ans+=(x*y*c);
    }
    cout<<ans<<endl;
    return 0;
}
#include<iostream>
using namespace std;
int a,br1[1024],br2[1024],n,m;

void read()
{
    int i;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>a;
        br1[a]=1;
    }
    cin>>m;
    for(i=0;i<m;i++)
    {
        cin>>a;
        br2[a]=1;
    }
}

void print()
{
    int i;
    for(i=0;i<1024;i++)
    if(br1[i]==1 && br2[i]==0)cout<<i<<' ';
    cout<<endl;
}

void solve()
{
    int i, ans=0;
    for(i=0;i<1024;i++)
    if((br1[i]==1 && br2[i]==0)||(br1[i]==0 && br2[i]==1))
    {
        print();
        return;
    }
    for(i=0;i<1024;i++)
    if(br1[i]==1)ans++;
    cout<<ans<<endl;
}
int main()
{
    read();
    solve();
    return 0;
}
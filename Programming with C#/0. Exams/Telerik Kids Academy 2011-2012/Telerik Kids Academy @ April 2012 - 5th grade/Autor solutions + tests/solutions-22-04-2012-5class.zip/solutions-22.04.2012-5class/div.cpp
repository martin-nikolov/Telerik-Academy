#include<iostream>
using namespace std;
int n,m;
int nod(int x, int y)
{
    while(x!=y)
    {
        if(x>y)x-=y;
        else y-=x;
    }
    return x;
}

void print(int x)
{
    int lamp=0;
    if(x==1)
    {
        cout<<"-1"<<endl;
        return;
    }
    int p=2;
    while(x!=1)
    {
        if(x%p==0)
        {
            if(lamp==0)
            {
                cout<<p<<' ';
                lamp=1;
            }
            x/=p;
        }
        else
        {
            p++;
            lamp=0;
        }
    }
    cout<<endl;
}

int main ()
{
    int i,p;
    cin>>n>>m;
    p=nod(n,m);
    print(p);
    return 0;
}
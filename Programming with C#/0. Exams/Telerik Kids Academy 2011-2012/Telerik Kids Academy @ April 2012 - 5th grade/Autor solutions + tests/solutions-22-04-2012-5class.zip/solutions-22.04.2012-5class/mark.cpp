#include<iostream>
#include<cmath>
using namespace std;
int main()
{
    int i,max_a,min_a,avr=0,n,a,sum=0;
    cin>>n;
    cin>>a;
    min_a=a;
    max_a=a;
    sum+=a;
    for(i=1;i<n;i++)
    {
        cin>>a;
        if(a>max_a)max_a=a;
        if(a<min_a)min_a=a;
        sum+=a;
    }
    sum-=(min_a+max_a);
    avr=round(double(sum)/double(n-2));
    cout<<avr<<endl;
    return 0;
}
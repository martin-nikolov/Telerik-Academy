#include <iostream>
using namespace std;

int main ()
{
    int w_bus,h_bus,a,b,i,n;
    cin>>w_bus>>h_bus;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>a>>b;
        if(w_bus>a || h_bus>b)
        {
            cout<<i<<endl;
            return 0;
        }
    }
    cout<<"No crash"<<endl;
    return 0;
}


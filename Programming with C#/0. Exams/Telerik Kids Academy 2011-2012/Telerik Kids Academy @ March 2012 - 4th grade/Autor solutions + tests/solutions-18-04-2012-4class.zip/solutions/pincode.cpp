#include <iostream>
using namespace std;
int main ()
{
    int a,b,oa,ob;
    cin>>a>>b;
    oa=100*(a%10)+10*(a/10%10)+a/100;
    ob=100*(b%10)+10*(b/10%10)+b/100;
    if(oa>ob)cout<<oa<<endl;
    else cout<<ob<<endl;
    return 0;
}
#include <iostream>
using namespace std;
int main ()
{
    int a,b,c,d;
    cin>>a>>b>>c>>d;
    if(a<b && b<c && c<d)cout<<"Ascending"<<endl;
    else if(a>b && b>c && c>d)cout<<"Descending"<<endl;
    else cout<<"Mixed"<<endl;
    return 0;
}

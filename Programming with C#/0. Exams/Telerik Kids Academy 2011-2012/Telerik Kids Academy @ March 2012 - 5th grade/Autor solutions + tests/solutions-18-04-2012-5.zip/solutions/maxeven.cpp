#include <iostream>
using namespace std;


int main ()
{
    int n=0,maxn=0,lamp=0;
    char ch;
    do
    {
        cin>>ch;
        if(ch-'0'==0) lamp = 1;
        if(ch>='0' && ch<='9')
        {
            n*=10;
            n+=(ch-'0');
        }
        else
        {
            if(n && n%2==0 && n>maxn)
            {
                maxn=n;
                lamp=1;
            }
            n=0;
        }
    }
    while(ch!='.');
    if(lamp)cout<<maxn<<endl;
    else cout<<"-1"<<endl;
    return 0;
}
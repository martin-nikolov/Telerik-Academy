#include <iostream>
using namespace std;
int nod(int a, int b)
{
  while(a!=b)
  if(a>b)a-=b;
  else b-=a;
}
int mutator(int x)
{
  int mx=0,c;
  do
  {
   c=x%10;
   if(c==0) c=9;
   else
   if(c==9) c=0;
   else
   if(c%2==0)c--;
   else c++;
   mx=mx*10+c;
   x/=10;
  }
  while(x);
  while(mx)
  {
    x=x*10+mx%10;
    mx/=10;
  }
  return x;
}
int main()
{
  int n, a, i, br=0, p;
  cin>>n;
  for(i=1;i<=n;i++)
  {
    cin>>a;
    p=nod(a, mutator(a));
    if(p<10)br++;
  }
  cout<<br<<endl;
  return 0;
}

﻿using System;
using System.Linq;

abstract class Cat : Animal
{
    public Cat(string name, uint age, Sex sex) : base(name, age, sex)
    {
    }
}
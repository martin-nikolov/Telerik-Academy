﻿using System;
using System.Linq;

interface ISound
{
    string Sound();
}
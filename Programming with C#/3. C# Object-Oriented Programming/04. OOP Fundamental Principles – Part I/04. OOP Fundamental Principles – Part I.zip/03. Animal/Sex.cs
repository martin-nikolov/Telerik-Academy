﻿using System;
using System.Linq;

public enum Sex
{
    Male,
    Female
}
﻿using System;
using System.Linq;

public interface ICommentable
{
    string Comment { get; set; }
}
﻿using System;
using System.Linq;

public enum CustomerType
{
    Individual,
    Company
}
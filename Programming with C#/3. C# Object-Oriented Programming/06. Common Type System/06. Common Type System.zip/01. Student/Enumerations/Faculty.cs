﻿using System;
using System.Linq;

enum Faculty
{
    None,
    Academic,
    Clinical, 
    CulpeperAppointed,
    SecondaryAppointments
}
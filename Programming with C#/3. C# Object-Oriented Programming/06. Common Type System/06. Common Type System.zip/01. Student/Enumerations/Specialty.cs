﻿using System;
using System.Linq;

enum Specialty
{
    None,
    Anesthesiology,
    Dermatology, 
    EmergencyMedicine, 
    FamilyMedicine, 
    InternalMedicine,
    Cardiology, 
    Endocrinology,
    Gastroenterology,
    GeriatricMedicine,
    Oncology,
    Hematology,
    Hospice, 
    PalliativeMedicine,
    InfectiousDisease,
    Nephrology,
    PulmonaryDisease,
    Rheumatology,
    Neurology,
    Ophthalmology,
    Neurosurgery
}
﻿using System;
using System.Linq;

enum University
{
    None,
    Cambridge,
    Oxford	,
    Edinburgh,
    UniversityCollegeLondon,
    Aberdeen,
    ImperialCollegeLondon,
    QueenMary,	
    Newcastle,
    Birmingham,
    Manchester,
    QueensBelfast,
    Southampton	
}
﻿namespace Prototype
{
    public abstract class StormtrooperPrototype
    {
        public abstract Stormtrooper Clone();
    }
}

﻿namespace SimpleFactory
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class Developer : Employee
    {
        public Developer()
        {
            this.Salary = 600;
        }
    }
}

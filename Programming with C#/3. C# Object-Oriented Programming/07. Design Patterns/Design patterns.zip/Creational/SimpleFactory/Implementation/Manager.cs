﻿namespace SimpleFactory
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class Manager : Employee
    {
        public Manager()
        {
            this.Salary = 1000;
        }
    }
}

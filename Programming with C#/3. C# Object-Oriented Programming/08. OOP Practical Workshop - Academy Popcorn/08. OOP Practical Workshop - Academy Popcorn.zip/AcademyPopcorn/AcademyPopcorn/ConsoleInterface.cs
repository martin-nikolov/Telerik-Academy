﻿using System;
using System.Linq;

namespace AcademyPopcorn
{
    public class ConsoleInterface
    {
    }
}
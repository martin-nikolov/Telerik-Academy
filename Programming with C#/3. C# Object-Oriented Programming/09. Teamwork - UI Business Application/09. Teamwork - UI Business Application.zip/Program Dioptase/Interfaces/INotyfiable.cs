﻿using System;
using System.Linq;

namespace ProgramDioptase.Interfaces
{
    public interface INotyfiable
    {
        void Notify();
    }
}
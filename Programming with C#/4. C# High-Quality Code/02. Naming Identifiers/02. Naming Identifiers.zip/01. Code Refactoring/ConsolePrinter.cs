﻿namespace IOEngine
{
    using System;
    using System.Linq;

    public class ConsolePrinter
    {
        public void Print(bool value)
        {
            Console.WriteLine(value);
        }
    }
}
﻿namespace IOEngine
{
    using System;
    using System.Linq;

    public class ConsolePrinterDemo
    {
        public static void Main()
        {
            ConsolePrinter consolePrinter = new ConsolePrinter();
            consolePrinter.Print(true);
        }
    }
}
﻿namespace IOEngine
{
    using System;
    using System.Linq;

    public class ConsoleWriter
    {
        public void Print(bool value)
        {
            Console.WriteLine(value);
        }
    }
}
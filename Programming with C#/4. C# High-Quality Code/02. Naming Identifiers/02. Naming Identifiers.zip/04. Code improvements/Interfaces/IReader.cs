﻿namespace Games.Interfaces
{
    using System;
    using System.Linq;

    public interface IReader
    {
        string ReadCommand();
    }
}
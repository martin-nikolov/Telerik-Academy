﻿namespace Games
{
    using System;
    using System.Linq;

    public class MinesGameDemo
    {
        public static void Main()
        {
            MinesGame minesGame = new MinesGame();
            minesGame.Start();
        }
    }
}
namespace Cooking.Food
{
    public class Carrot : NaturalFood
    {
    }
}
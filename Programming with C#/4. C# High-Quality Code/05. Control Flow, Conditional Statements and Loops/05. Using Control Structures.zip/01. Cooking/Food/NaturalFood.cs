namespace Cooking.Food
{
    public abstract class NaturalFood
    {
    }
}
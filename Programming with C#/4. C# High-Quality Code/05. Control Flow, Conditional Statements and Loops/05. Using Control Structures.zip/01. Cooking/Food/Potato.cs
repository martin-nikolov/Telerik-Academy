namespace Cooking.Food
{
    public class Potato : NaturalFood
    {
        public bool IsPeeled { get; set; }

        public bool IsRotten { get; set; }
    }
}
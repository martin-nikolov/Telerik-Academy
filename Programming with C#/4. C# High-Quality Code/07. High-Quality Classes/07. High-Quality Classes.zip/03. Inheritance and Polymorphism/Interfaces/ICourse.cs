﻿namespace InheritanceAndPolymorphism.Interfaces
{
    using System;
    using System.Linq;

    public interface ICourse
    {
        string Name { get; set; }

        string TeacherName { get; set; }

        string ToString();

        void AddStudents(params string[] studentNames);
    }
}
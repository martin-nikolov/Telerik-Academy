﻿namespace SingleResponsibilityShapesAfter.Contracts
{
    public interface IDrawingContext
    {
    }
}

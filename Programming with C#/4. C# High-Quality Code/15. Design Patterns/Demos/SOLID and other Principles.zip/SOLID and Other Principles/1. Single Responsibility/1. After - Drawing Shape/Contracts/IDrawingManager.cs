﻿namespace SingleResponsibilityShapesAfter.Contracts
{
    public interface IDrawingManager
    {
        void Draw(IShape shape);
    }
}

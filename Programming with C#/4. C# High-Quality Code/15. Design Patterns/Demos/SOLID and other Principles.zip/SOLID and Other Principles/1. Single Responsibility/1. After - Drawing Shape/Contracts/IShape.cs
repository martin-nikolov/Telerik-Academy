﻿namespace SingleResponsibilityShapesAfter.Contracts
{
    public interface IShape
    {
        decimal Area { get; }
    }
}

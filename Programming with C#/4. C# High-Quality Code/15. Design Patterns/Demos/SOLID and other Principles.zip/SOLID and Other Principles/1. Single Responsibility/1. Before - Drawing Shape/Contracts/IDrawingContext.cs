﻿namespace SingleResponsibilityShapesBefore.Contracts
{
    public interface IDrawingContext
    {
    }
}

﻿namespace SingleResponsibilityShapesBefore.Contracts
{
    public interface IDrawingManager
    {
        void Draw(IShape shape);
    }
}

﻿namespace OpenClosedFileDownloadBefore
{
    public class File
    {
        public string Name { get; set; }

        public int Length { get; set; }

        public int Sent { get; set; }
    }
}

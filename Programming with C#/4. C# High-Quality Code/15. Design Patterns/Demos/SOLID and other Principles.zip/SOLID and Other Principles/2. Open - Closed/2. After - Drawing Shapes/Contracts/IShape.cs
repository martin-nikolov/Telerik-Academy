﻿namespace OpenClosedDrawingShapesAfter.Contracts
{
    public interface IShape
    {
    }
}

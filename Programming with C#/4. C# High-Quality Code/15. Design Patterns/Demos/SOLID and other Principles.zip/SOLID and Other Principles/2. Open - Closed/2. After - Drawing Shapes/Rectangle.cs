﻿namespace OpenClosedDrawingShapesAfter
{
    using OpenClosedDrawingShapesAfter.Contracts;

    public class Rectangle : IShape
    {
    }
}

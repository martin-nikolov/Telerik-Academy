﻿namespace OpenClosedDrawingShapesBefore.Contracts
{
    public interface IShape
    {
    }
}

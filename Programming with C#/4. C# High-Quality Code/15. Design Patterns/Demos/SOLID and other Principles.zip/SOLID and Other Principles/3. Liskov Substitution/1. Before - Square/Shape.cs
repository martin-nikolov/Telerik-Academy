﻿namespace LiskovSubstitutionSquareBefore
{
    public abstract class Shape
    {
        public abstract decimal Area { get; }
    }
}

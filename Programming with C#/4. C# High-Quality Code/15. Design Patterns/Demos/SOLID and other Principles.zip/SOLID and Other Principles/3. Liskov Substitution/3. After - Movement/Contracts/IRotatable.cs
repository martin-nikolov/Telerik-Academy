﻿namespace LiskovSubstitutionMovementAfter.Contracts
{
    public interface IRotatable : IMovable
    {
        void Rotate();
    }
}

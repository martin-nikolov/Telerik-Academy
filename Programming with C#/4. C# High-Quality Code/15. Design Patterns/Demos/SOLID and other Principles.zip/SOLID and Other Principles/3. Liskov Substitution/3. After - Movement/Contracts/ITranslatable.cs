﻿namespace LiskovSubstitutionMovementAfter.Contracts
{
    public interface ITranslatable : IMovable
    {
        void Translate();
    }
}

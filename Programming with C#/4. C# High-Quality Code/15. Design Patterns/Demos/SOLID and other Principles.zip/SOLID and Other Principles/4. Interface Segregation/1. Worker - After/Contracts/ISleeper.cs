﻿namespace InterfaceSegregationWorkerAfter.Contracts
{
    public interface ISleeper
    {
        void Sleep();
    }
}

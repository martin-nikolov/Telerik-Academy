﻿namespace InterfaceSegregationWorkerAfter
{
    using InterfaceSegregationWorkerAfter.Contracts;

    public class Robot : IWorker
    {
        public void Work()
        {
            // work
        }
    }
}

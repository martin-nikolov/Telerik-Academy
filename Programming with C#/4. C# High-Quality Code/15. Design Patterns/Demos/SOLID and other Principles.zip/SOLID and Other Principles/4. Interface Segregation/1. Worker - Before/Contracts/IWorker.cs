﻿namespace InterfaceSegregationWorkerBefore.Contracts
{
    public interface IWorker
    {
        void Eat();

        void Work();

        void Sleep();
    }
}

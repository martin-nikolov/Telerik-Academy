﻿namespace DependencyInversionWorkerBefore
{
    public class Worker
    {
        public void Work()
        {
            // do the work
        }
    }
}

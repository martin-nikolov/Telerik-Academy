﻿namespace KISSMp3MoverBefore.Contracts
{
    public interface IFileRenameStrategy
    {
        void Rename(string fileName);
    }
}

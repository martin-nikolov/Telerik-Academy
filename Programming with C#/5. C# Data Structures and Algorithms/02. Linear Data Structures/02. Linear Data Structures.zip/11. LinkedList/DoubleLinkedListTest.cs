﻿/*
 * 11. Implement the data structure linked list. Define a class
 * ListItem<T> that has two fields: value (of type T) and NextItem
 * (of type ListItem<T>). Define additionally a class LinkedList<T>
 * with a single field FirstElement (of type ListItem<T>).
 */

namespace DynamicList
{
    using System;

    public class DoubleLinkedListTest
    {
        public static void Main()
        {
            // There are Unit-Tests -> See LinearDataStructures.Tests -> DoubleLinkedListTests
        }
    }
}
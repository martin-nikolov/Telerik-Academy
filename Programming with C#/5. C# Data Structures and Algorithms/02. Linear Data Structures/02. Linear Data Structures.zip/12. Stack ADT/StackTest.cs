﻿/*
 * 12. Implement the ADT stack as auto-resizable array.
 * Resize the capacity on demand (when no space is available 
 * to add / insert a new element).
 */

namespace AbstractDataStructures
{
    using System;

    public class StackTest
    {
        public static void Main()
        {
            // There are Unit-Tests -> See LinearDataStructures.Tests -> StackTests
        }
    }
}
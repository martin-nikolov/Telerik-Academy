﻿/*
 * 13. Implement the ADT queue as dynamic linked list. 
 * Use generics (LinkedQueue<T>) to allow storing different
 * data types in the queue.
 */

namespace AbstractDataStructures
{
    public class QueueTest
    {
        public static void Main()
        {
            // There are Unit-Tests -> See LinearDataStructures.Tests -> QueueTests
        }
    }
}
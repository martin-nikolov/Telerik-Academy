﻿/*
 * 1. Implement a class PriorityQueue<T> based on 
 * the data structure "binary heap".
 */

namespace AdvancedDataStructures
{
    using System;
    using System.Linq;

    public class PriorityQueueTests
    {
        public static void Main()
        {
            // There are Unit-Tests -> See AdvancedDataStructures.Tests -> PriorityQueueTests
        }
    }
}
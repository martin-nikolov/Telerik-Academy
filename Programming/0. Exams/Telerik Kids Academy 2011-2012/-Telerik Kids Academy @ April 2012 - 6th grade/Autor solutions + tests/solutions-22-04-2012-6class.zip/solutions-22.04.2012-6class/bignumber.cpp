#include <iostream>
#include <string>
using namespace std;

string num,s,ans;
int n;

void read()
{
    int i;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>s;
        num+=s;
    }
}
int pal(int i, int j)
{
    while(i<=j)
    {
        if(num[i]!=num[j])return 0;
        i++;
        j--;
    }
    return 1;
}
void solve()
{
    int i,j,sz,max_sz=0, first_pos, last_pos;
    string temp;
    sz = num.size();
    for(i=0;i<sz;i++)
    for(j=i;j<sz;j++)
    {
        if(num[i]!='0' && pal(i,j))
        {
            if(max_sz<((j-i)+1))
            {
                max_sz = (j-i)+1;
                ans=num.substr(i,(j-i)+1);
            }
            else
            if(max_sz==((j-i)+1))
            {
                temp=num.substr(i,(j-i)+1);
                if(temp>ans)ans=temp;
                max_sz=ans.size();
            }
        }
    }
    cout<<ans<<endl;
}

int main ()
{
    read();
    solve();
    return 0;
}

#include <iostream>
#include <cstring>

using namespace std;

int n, m, chars;
char puzzle[32][32],solution[32] = "~",word[32];

void append( char x )
{
   if( x != '#' )
   {
      word[chars++] = x;
   }
   else
   {
      word[chars] = 0;
      if( chars >= 2 && strcmp( word, solution ) < 0 )
         strcpy( solution, word );
      chars = 0;
   }
}

int main()
{
    int i,j;
    cin>>n>>m;
    for(i = 0; i < n; i++ ) cin>>puzzle[i];
    for(i = 0; i < n; i++ )
    {
        for(j = 0; j < m; j++ ) append( puzzle[i][j] );
        append( '#' );
    }

    for(j = 0; j < m; j++ )
    {
        for(i = 0; i < n; i++ )append( puzzle[i][j] );
        append( '#' );
    }

   cout<<solution<<endl;
   return 0;
}

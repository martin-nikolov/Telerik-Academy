#include <iostream>
using namespace std;
int main()
{
   int n,d=1;
   cin>>n;
   do
   {
       d = d + 1;
       if( d*d > n ) d = n;
   }
   while( n%d != 0 );

   printf( "%d\n", n-(n/d) );

   return 0;
}

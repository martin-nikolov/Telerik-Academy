#include <iostream>
using namespace std;
int main()
{
    long long int n, k, i, br_cif=0;
    cin>>n>>k;
    while(k)
    {
        if(k%10)br_cif++;
        k/=10;
    }
    if(br_cif>=n)cout<<'0'<<endl;
    else cout<<n-br_cif<<endl;
    return 0;
}

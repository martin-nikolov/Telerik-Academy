#include <iostream>
#include <string>
using namespace std;

int main()
{
    int sz, ans=0, max_ans=0, i, lamp=0, br=0;
    string text;
    getline(cin,text);
    sz = text.size();
    for(i=0; i<sz; i++)
    {
        if(!((text[i]>='a' && text[i]<='z') || (text[i]>='A' && text[i]<='Z')) &&
        text[i]!='.' && text[i]!=' ' && !(text[i]>='0' && text[i]<='9'))
        {
            ans++;
            if(lamp==0)
            {
                br++;
                lamp=1;
            }
        }
        else
        {
            if(ans>max_ans) max_ans=ans;
            ans=0;
            lamp=0;
        }
    }
    if(ans>max_ans) max_ans=ans;
    cout<<br<<' '<<max_ans<<endl;
    return 0;
}





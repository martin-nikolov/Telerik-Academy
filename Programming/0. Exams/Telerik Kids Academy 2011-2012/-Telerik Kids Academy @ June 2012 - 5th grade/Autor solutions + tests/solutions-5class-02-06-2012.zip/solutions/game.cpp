#include <iostream>
using namespace std;

int n, k, ans[1024], divs[1024], sz, maxpoints;

void find_div(int x)
{
    int i;
    for(i=2;i<=x/2;i++)
    if(x%i==0) divs[sz++]=i;
    divs[sz++]=x;
}

int div(int x)
{
    int i, points=0;
    for(i=0;i<sz;i++)
    if(x%divs[i]==0)points++;
    return points;
}

int main()
{
    int i,a;
    cin>>n>>k;
    find_div(k);

    for(i=1;i<=n;i++)
    {
        cin>>a;
        ans[i]=div(a);
        if(ans[i]>maxpoints)maxpoints=ans[i];
    }

    if(maxpoints)
    {
        cout<<maxpoints<<endl;
        for(i=1;i<=n;i++)
        if(ans[i]==maxpoints)cout<<i<<' ';
        cout<<endl;
    }
    else cout<<"No winners\n";

    return 0;
}



#include <iostream>
using namespace std;

long long n, k;

void solve (long long int x)
{
    int br_cif=0, sum_cif=0, i, rem, num;
    while(k)
    {
        sum_cif+=k%10;
        k/=10;
        br_cif++;
    }

    if(sum_cif<n)
    {
        cout<<n-sum_cif<<endl;
        return;
    }

    num=sum_cif/n;
    rem=sum_cif%n;

    for(i=0;i<n;i++)
    {
        if(rem)
        {
            cout<<num+1;
            rem--;
        }
        else cout<<num;
    }
    cout<<endl;
}

void read()
{
    cin>>n>>k;
}

int main()
{
    read();
    solve(k);
    return 0;
}


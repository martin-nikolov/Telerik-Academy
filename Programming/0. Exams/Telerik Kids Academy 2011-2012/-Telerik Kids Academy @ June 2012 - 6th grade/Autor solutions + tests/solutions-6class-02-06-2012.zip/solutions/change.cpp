#include <iostream>
using namespace std;

int EqualStrings (string &a, string &b)//dobavia nuli v nachaloto na po-kysiq string
{
    int sz1,sz2,diff,max_sz,i;

    sz1=a.size();
    sz2=b.size();

    if(sz1<sz2)
    {
        diff=sz2-sz1;
        max_sz=sz2;
        for(i=0;i<diff;i++)a='0'+a;
    }
    else
    {
        diff=sz1-sz2;
        max_sz=sz1;
        for(i=0;i<diff;i++)b='0'+b;
    }
    return max_sz;
}

void print(string s)//otpechatva rezultata bez vodeshti nuli
{
    int i=0, sz=s.size();
    while(s[i]=='0') i++;
    if(i==sz)cout<<'0';
    else for(;i<sz;i++) cout<<s[i];
    cout<<endl;
}

void DiffBigNums(string bigNum1, string bigNum2)//izvajda ot po-golqmoto po-malkoto chislo
{
    int sz1,sz2,i,diff,max_sz,rem=0,digit1,digit2,sum,pos;
    string result="";

    sz1=bigNum1.size();
    sz2=bigNum2.size();

    if(sz2>sz1)swap(bigNum1, bigNum2);
    if((sz1==sz2) && (bigNum1 < bigNum2))swap(bigNum1, bigNum2);

    max_sz=EqualStrings(bigNum1, bigNum2);

    for(i=max_sz-1;i>=0;i--)
    {
        digit1=(bigNum1[i]-'0')-rem;
        digit2=(bigNum2[i]-'0');
        rem=0;
        if(digit1>=digit2)
        {
            sum=digit1-digit2;
            result=(char)(sum+'0')+result;
        }
        else
        {
            digit1+=10;
            sum=digit1-digit2;
            result=(char)(sum+'0')+result;
            rem=1;
        }
    }
    print(result);
}

int main ()
{
    string s1, s2;
    cin>>s1>>s2;
    DiffBigNums(s1,s2);
    return 0;
}
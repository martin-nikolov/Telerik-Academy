#include <iostream>
using namespace std;
int a[128],cn=1,n,i,mh=0;
int main()
{
	cin>>n;
	cin>>a[0];
	mh=a[0];
	for(i=1;i<n;i++)
	{
		cin>>a[i];
		if(a[i]>mh)
		{
			cn++;
			mh=a[i];
		}
	}
	cout<<cn<<" ";
	cn=1;
	mh=a[n-1];
	for(i=n-2;i>=0;i--)
	{
		if(a[i]>mh)
		{
			cn++;
			mh=a[i];
		}
	}
	cout<<cn<<endl;
	return 0;
}

#include <iostream>
using namespace std;

int sum,j,n,a[32],minr;

void check(int k)
{
    if(abs(2*k-sum)<minr)minr=abs(2*k-sum);
}


void solve(int i, int k)
{
    check(k);
    if(i==n)return;
    solve(i+1,k+a[i]);
    solve(i+1,k);
}


int main()
{
    cin>>n;
    for(j=0;j<n;j++)
    {
        cin>>a[j];
        sum+=a[j];
    }
    minr=sum;
    solve(0,0);
    cout<<minr<<endl;
}

#include <iostream>
using namespace std;
int n,r,s,dam[16],res[16];

void read ()
{
    int i,a;
    cin>>n>>s>>r;
    for(i=0;i<s;i++)
    {
        cin>>a;
        dam[a]=1;
    }
    for(i=0;i<r;i++)
    {
        cin>>a;
        res[a]=1;
    }
}

void solve ()
{
    int i,ans=0;
    for(i=1;i<=n;i++)
    {
        if(i==1 && dam[i])
        {
            if(res[i+1]) res[i+1]=0;
            else ans++;
        }
        else
        if(i==n && dam[i])
        {
            if(res[i-1]) res[i-1]=0;
            else ans++;
        }
        else
        {
            if(dam[i])
            {
                if(res[i-1])res[i-1]=0;
                else if(res[i+1])res[i+1]=0;
                else ans++;
            }
        }
    }
    cout<<ans<<endl;
}

int main ()
{
    read();
    solve();
    return 0;
}
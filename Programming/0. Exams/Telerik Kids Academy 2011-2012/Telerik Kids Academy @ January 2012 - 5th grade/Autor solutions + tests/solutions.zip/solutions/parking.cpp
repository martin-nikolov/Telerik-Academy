#include <iostream>

using namespace std;

char a[64][64];
int n,m;

void read ()
{
    int i, j;
    cin >> n >> m;
    for(i=0; i<n; i++)
    for(j=0; j<m; j++)cin>>a[i][j];
}
void solve()
{
    int br0=0,br1=0,br2=0,br3=0,br4=0,i,j,cn=0;
    for(i=0;i<n-1;i++)
    for(j=0;j<m-1;j++)
    {
        cn=0;
        if(a[i][j]!='#'&&a[i][j+1]!='#'&&a[i+1][j]!='#'&&a[i+1][j+1]!='#')
        {
            if(a[i][j]=='X')cn++;
            if(a[i][j+1]=='X')cn++;
            if(a[i+1][j]=='X')cn++;
            if(a[i+1][j+1]=='X')cn++;

            if(cn==0)br0++;
            if(cn==1)br1++;
            if(cn==2)br2++;
            if(cn==3)br3++;
            if(cn==4)br4++;
        }

    }
    cout<<br0<<endl;
    cout<<br1<<endl;
    cout<<br2<<endl;
    cout<<br3<<endl;
    cout<<br4<<endl;
}
int main ()
{
    read();
    solve();
    return 0;
}
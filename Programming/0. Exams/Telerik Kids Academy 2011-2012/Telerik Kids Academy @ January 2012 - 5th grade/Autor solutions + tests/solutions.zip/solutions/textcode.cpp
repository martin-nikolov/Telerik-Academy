#include <iostream>
#include <string>
using namespace std;

void gen(string s, int k)
{
  if(k==0){cout<<s[k];return;}
  gen(s,k-1);
  cout<<s[k];
  gen(s,k-1);
}
int main()
{
  string s;
  cin>>s;
  gen(s,s.size()-1);
  cout<<endl;
  return 0;
}

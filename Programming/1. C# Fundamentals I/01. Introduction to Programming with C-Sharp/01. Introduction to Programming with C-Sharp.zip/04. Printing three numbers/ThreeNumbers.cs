﻿// 4. Write a program to print the numbers 1, 101 and 1001.

using System;

class ThreeNumbers
{
    static void Main(string[] args)
    {
        Console.WriteLine(1);
        Console.WriteLine(101);
        Console.WriteLine(1001);
    }
}

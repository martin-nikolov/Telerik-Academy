﻿// 8. Create a console application that calculates and 
// prints the square of the number 12345.

using System;

class SquareOfNumber
{
    static void Main(string[] args)
    {
        double number = 12345;

        Console.WriteLine("Square of {0} is {1}", number, number * number);
    }
}
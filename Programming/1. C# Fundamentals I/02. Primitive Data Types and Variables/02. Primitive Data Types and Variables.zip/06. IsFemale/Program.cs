﻿/*
* 6. Declare a boolean variable called isFemale and assign an
* appropriate value corresponding to your gender.
*/

using System;

class Program
{
    static void Main(string[] args)
    {
        bool isFemale = false;
        Console.WriteLine("My gender is female: {0}", isFemale);
    }
}
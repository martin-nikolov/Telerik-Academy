exports.tests = [
	// Font sizes
	{name:"font size of the title", points: 4, func:function(){
		return $("header>h1").css("font-size");
	}, expected: "16px", compare: "equal", compareParam: null},
	
	{name:"font size of the menu", points: 4, func:function(){
		return $("#nav>ul>li").css("font-size");
	}, expected: "14px", compare: "equal", compareParam: null},
	
	{name:"font size of the archive", points: 3, func:function(){
		return $("#archives>a").css("font-size");
	}, expected: "14px", compare: "equal", compareParam: null},
	
	{name:"font size of the search", points: 3, func:function(){
		return $("#search>a").css("font-size");
	}, expected: "14px", compare: "equal", compareParam: null},
	
	{name:"font size of the content title", points: 4, func:function(){
		return $("#content>h1").css("font-size");
	}, expected: "24px", compare: "equal", compareParam: null},
	
	{name:"font size of the content", points: 4, func:function(){
		return $("#content>article>p").css("font-size");
	}, expected: "14px", compare: "equal", compareParam: null},
	
	
	// Colors
	{name:"title text color difference", points: 3, func:function(){
		return $.xcolor.distance($("header>h1").css("color"), "#575E5B");
	}, expected: 0, compare: "equalDiff", compareParam: 15},
		
	{name:"menu text color difference", points: 2, func:function(){
		return $.xcolor.distance($("#nav>ul>li").css("color"), "#575E5B");
	}, expected: 0, compare: "equalDiff", compareParam: 15},
		
	{name:"archive text color difference", points: 3, func:function(){
		return $.xcolor.distance($("#archives>a").css("color"), "#C6C6C6");
	}, expected: 0, compare: "equalDiff", compareParam: 15},
		
	{name:"search text color difference", points: 2, func:function(){
		return $.xcolor.distance($("#search>a").css("color"), "#C6C6C6");
	}, expected: 0, compare: "equalDiff", compareParam: 15},
		
	{name:"content title text color difference", points: 3, func:function(){
		return $.xcolor.distance($("#content>h1").css("color"), "#575E5B");
	}, expected: 0, compare: "equalDiff", compareParam: 15},
		
	{name:"content text color difference", points: 2, func:function(){
		return $.xcolor.distance($("#content>article>p").css("color"), "#575E5B");
	}, expected: 0, compare: "equalDiff", compareParam: 15},
	
	
	// Page
	{name:"No padding or margin at the start of the page", points: 2, func:function(){
		return $("header").offset().top;
	}, expected: 0, compare: "equal", compareParam: null},
	
	
	// Header
	{name:"Header height", points: 5, func:function(){
		return $("header").outerHeight();
	}, expected: 49, compare: "equalDiff", compareParam: 2},
	
	{name:"Header has background image", points: 4, func:function(){
		return $("header").css("background-image").indexOf("header-bg.png") > -1;
	}, expected: true, compare: "equal", compareParam: null},
	
	
	// Header title
	{name:"Header title left offset is correct", points: 4, func:function(){
		return $("header>h1").offset().left
			+ parseInt($("header>h1").css("padding-left"))
			+ parseInt($("header>h1").css("margin-left"));
	}, expected: 15, compare: "equalDiff", compareParam: 4},
	
	{name:"Header title top offset is correct", points: 4, func:function(){
		return $("header>h1").offset().top
			+ parseInt($("header>h1").css("padding-top"))
			+ parseInt($("header>h1").css("margin-top"));
	}, expected: 15, compare: "equalDiff", compareParam: 2},
	
	{name:"Header title is uppercased", points: 4, func:function(){
		return $("header>h1").css("text-transform");
	}, expected: "uppercase", compare: "equal", compareParam: null},
	
	
	// Menu (navigation)
	{name:"Menu is right floated", points: 5, func:function(){
		return $("#nav>ul>li").eq(0).offset().left;
	}, expected: 712, compare: "equalDiff", compareParam: 100},
	
	{name:"Menu top offset is correct", points: 4, func:function(){
		return $("#nav>ul>li").eq(0).offset().top
			+ parseInt($("#nav>ul>li").eq(0).css("padding-top"))
			+ parseInt($("#nav>ul>li").eq(0).css("margin-top"));
	}, expected: 17, compare: "equalDiff", compareParam: 2},
	
	{name:"distance between two menu links", points: 4, func:function(){
		var a1 = $("#nav>ul>li").eq(0).offset().left;
		var a2 = $("#nav>ul>li").eq(1).offset().left;
		return Math.abs(a1 - a2);
	}, expected: 57, compare: "equalDiff", compareParam: 3},
	
	{name:"two menu links are on the same line", points: 5, func:function(){
		var a1 = $("#nav>ul>li").eq(0).offset().top;
		var a2 = $("#nav>ul>li").eq(1).offset().top;
		return Math.abs(a1 - a2);
	}, expected: 0, compare: "equal", compareParam: null},
	
	
	// Search bar and archive
	{name:"searchBar has black background color", points: 4, func:function(){
		return $.xcolor.distance($("#searchBar").css("background-color"), "#000000");
	}, expected: 0, compare: "equalDiff", compareParam: 15},
	
	{name:"horizontal offset between archive links and searchBar", points: 3, func:function(){
		var a1 = $("#searchBar").offset().top;
		var a2 = $("#archives>a").eq(0).offset().top;
		return Math.abs(a1 - a2);
	}, expected: 10, compare: "equalDiff", compareParam: 2},
	
	{name:"vertical offset between archive links and searchBar", points: 3, func:function(){
		var a1 = $("#searchBar").offset().left;
		var a2 = $("#archives>a").eq(0).offset().left;
		return Math.abs(a1 - a2);
	}, expected: 19, compare: "equalDiff", compareParam: 3},
	
	{name:"archive links and search text are on the same line", points: 4, func:function(){
		var a1 = $("#archives>a").eq(0).offset().top;
		var a2 = $("#search>a").offset().top;
		return Math.abs(a1 - a2);
	}, expected: 0, compare: "equal", compareParam: null},

	{name:"archive links are not underlined", points: 4, func:function(){
		return $("#archives>a").css("text-decoration");
	}, expected: "none", compare: "equal", compareParam: null},
	
	{name:"search is right floated", points: 4, func:function(){
		return $("#search>a").offset().left;
	}, expected: 911, compare: "equalDiff", compareParam: 50},
];

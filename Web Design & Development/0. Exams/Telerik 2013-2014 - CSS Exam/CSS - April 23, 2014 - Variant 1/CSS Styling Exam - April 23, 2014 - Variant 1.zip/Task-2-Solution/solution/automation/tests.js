exports.tests = [
	// Font sizes
	//{name:"font size #content text", points: 2, func:function(){
	//	return $("#content>article>p").css("font-size");
	//}, expected: "14px", compare: "equal", compareParam: null},
	
	//// Content text
	//{name:"#content text color difference", points: 2, func:function(){
	//	return $.xcolor.distance($("#content p").css("color"), "rgb(51, 51, 51)");
	//}, expected: 0, compare: "equalDiff", compareParam: 15},
	
	//{name:"#content text is justified", points: 2, func:function(){
	//	return $("#content article").css("text-align");
	//}, expected: "justify", compare: "equal", compareParam: null},
	
	//// #archive elements
	//{name:"#archive elements text color difference", points: 2, func:function(){
	//	return $.xcolor.distance($("#archive>ul>li>a").css("color"), "rgb(51, 51, 51)");
	//}, expected: 0, compare: "equalDiff", compareParam: 15},
	
	//{name:"#archive links are not underlined", points: 2, func:function(){
	//	return $("#archive>ul>li>a").css("text-decoration");
	//}, expected: "none", compare: "equal", compareParam: null},
	
	//{name:"distance between two #archive links", points: 2, func:function(){
	//	var a1 = $("#archive>ul>li>a").eq(0).offset().left;
	//	var a2 = $("#archive>ul>li>a").eq(1).offset().left;
	//	return Math.abs(a1 - a2);
	//}, expected: 34, compare: "equalDiff", compareParam: 3},
	
	//{name:"#archive links are right floated", points: 2, func:function(){
	//	return $("#archive>ul>li>a").eq(5).offset().left;
	//}, expected: 935, compare: "equalDiff", compareParam: 10},
	
	//{name:"two #archive links are on the same line", points: 2, func:function(){
	//	var a1 = $("#archive>ul>li>a").eq(0).offset().top;
	//	var a2 = $("#archive>ul>li>a").eq(1).offset().top;
	//	return Math.abs(a1 - a2);
	//}, expected: 0, compare: "equal", compareParam: null},
	
	//{name:"almost no distance between #archive and #header", points: 2, func:function(){
	//	var a1 = $("#archive").offset().top;
	//	var a2 = $("#header").offset().top;
	//	return Math.abs(a1 - a2);
	//}, expected: 17, compare: "equalDiff", compareParam: 1},
	
	//{name:"0 distance between #archive and #header", points: 1, func:function(){
	//	var a1 = $("#archive").offset().top;
	//	var a2 = $("#header").offset().top;
	//	return Math.abs(a1 - a2);
	//}, expected: 17, compare: "equalDiff", compareParam: 0},
	
	
	//// Page
	//{name:"No padding or margin at the start of the page", points: 1, func:function(){
	//	return $("#archive").offset().top;
	//}, expected: 0, compare: "equal", compareParam: null},
	
	
	//// Header
	//{name:"Header height", points: 2, func:function(){
	//	return $("#header").height();
	//}, expected: 64, compare: "equalDiff", compareParam: 1},
	
	//{name:"No padding or margin at the start of the page", points: 1, func:function(){
	//	return $("#header").css("background-image");
	//}, expected: true, compare: "equal", compareParam: null},	
	
	// Variant 1 - Task 2
	//{
	//    name: 'Test hover', points: 2, func: function () {
	//        var el = $('.content a');
	//        el.toggleClass('hover');
	//        var value = el.css('text-decoration');
	//        el.toggleClass('hover');
	//        return value;


	//        // return jss('.content a:hover', 'text-decoration');
	//    }, expected: 'underline', compare: 'equal', compareParam: null
	//},
    {
        name: 'font size',
        points: 1,
        func: function () {
            return $('#wrapper').css('font-size');
        },
        expected: '16px',
        compare: 'equal',
        compareParam: null
    }, {
        name: 'font family',
        points: 1,
        func: function () {
            return $('#wrapper').css('font-family');
        },
        expected: "'Courier New', Courier, 'Nimbus Mono L', monospace",
        compare: 'equal',
        compareParam: null
    }, {
        name: 'width',
        points: 1,
        func: function () {
            return $('#wrapper').css('width');
        },
        expected: "960px",
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list style',
        points: 1,
        func: function () {
            return $('.menu').css('list-style-type');
        },
        expected: "none",
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list padding top',
        points: 1,
        func: function () {
            return $('.menu > li a').offset().top - $('.menu > li').offset().top;
        },
        expected: 11,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list padding bottom',
        points: 1,
        func: function () {
            return $('.menu > li a').offset().top + $('.menu > li a').height() - $('.menu > li').offset().top - $('.menu > li').height();
        },
        expected: 11,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list padding left',
        points: 1,
        func: function () {
            return $('.menu > li a').offset().left - $('.menu > li').offset().left;
        },
        expected: 21,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list padding right',
        points: 1,
        func: function () {
            return $('.menu > li a').offset().left + $('.menu > li a').width() - $('.menu > li').offset().left - $('.menu > li').width();
        },
        expected: 21,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list floating distance',
        points: 1,
        func: function () {
            var lis = $('.menu > li');
            var values = [];

            for (var i = 0; i < 2; i++) {
                var currentLi = $(lis[i]);
                var left = currentLi.offset().left;
                var width = currentLi.outerWidth();

                var nextLi = $(lis[i + 1]);
                var nextLeft = nextLi.offset().left;

                values.push(nextLeft - (left + width));
            }

            if (values[0] == values[1]) {
                return values[0];
            }
            else {
                return 'invalid';
            }
        },
        expected: 10,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list floating top',
        points: 1,
        func: function () {
            var lis = $('.menu > li');
            var values = [];

            for (var i = 0; i < 3; i++) {
                var currentLi = $(lis[i]);
                var top = currentLi.offset().top;
                values.push(top);
            }

            return values[0] == values[1] && values[1] == values[2];
        },
        expected: true,
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list height',
        points: 1,
        func: function () {
            var lis = $('.menu > li');
            var values = [];

            for (var i = 0; i < 3; i++) {
                var currentLi = $(lis[i]);
                var top = currentLi.height();
                values.push(top);
            }

            return values[0] == values[1] && values[1] == values[2];
        },
        expected: true,
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list gradient first color',
        points: 1,
        func: function () {
            var lis = $('.menu > li').css('linearGradientColors');
            return $.xcolor.distance('#24ddf2', lis[0]);
        },
        expected: 0,
        compare: 'equalDiff',
        compareParam: 30
    }, {
        name: 'menu list gradient second color',
        points: 1,
        func: function () {
            var lis = $('.menu > li').css('linearGradientColors');
            return $.xcolor.distance('#7a94e2', lis[1]);
        },
        expected: 0,
        compare: 'equalDiff',
        compareParam: 30
    }, {
        name: 'menu list border color',
        points: 1,
        func: function () {
            var leftColor = $('.menu > li').css('border-left-color');
            var rightColor = $('.menu > li').css('border-right-color');
            var topColor = $('.menu > li').css('border-top-color');
            var bottomColor = $('.menu > li').css('border-bottom-color');

            if (leftColor == rightColor && rightColor == topColor && bottomColor == topColor && leftColor == "rgb(0, 0, 0)") {
                return true;
            }
            else {
                return false; 
            }
        },
        expected: true,
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list border size',
        points: 1,
        func: function () {
            var leftColor = $('.menu > li').css('border-left-width');
            var rightColor = $('.menu > li').css('border-right-width');
            var topColor = $('.menu > li').css('border-top-width');
            var bottomColor = $('.menu > li').css('border-bottom-width');

            if (leftColor == rightColor && rightColor == topColor && bottomColor == topColor && leftColor == "1px") {
                return true;
            }
            else {
                return false;
            }
        },
        expected: true,
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list border style',
        points: 1,
        func: function () {
            var leftColor = $('.menu > li').css('border-left-style');
            var rightColor = $('.menu > li').css('border-right-style');
            var topColor = $('.menu > li').css('border-top-style');
            var bottomColor = $('.menu > li').css('border-bottom-style');

            if (leftColor == rightColor && rightColor == topColor && bottomColor == topColor && leftColor == "solid") {
                return true;
            }
            else {
                return false;
            }
        },
        expected: true,
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list border radius',
        points: 1,
        func: function () {
            var leftColor = $('.menu > li').css('border-top-left-radius');
            var rightColor = $('.menu > li').css('border-top-right-radius');
            var topColor = $('.menu > li').css('border-bottom-right-radius');
            var bottomColor = $('.menu > li').css('border-bottom-left-radius');

            if (leftColor == rightColor && rightColor == topColor && bottomColor == topColor) {
                return parseInt(leftColor);
            }
            else {
                return false;
            }
        },
        expected: 10,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list a color',
        points: 1,
        func: function () {
            return $.xcolor.distance($('.menu > li a').css('color'), "rgb(0, 0, 255)");
        },
        expected: 0,
        compare: 'equalDiff',
        compareParam: 30
    }, {
        name: 'menu list a text-decoration',
        points: 1,
        func: function () {
            return $('.menu > li a').css('text-decoration');
        },
        expected: 'none',
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list content visibility',
        points: 1,
        func: function () {
            return $('.menu > li .content').css('display');
        },
        expected: 'none',
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list content position',
        points: 1,
        func: function () {
            return $('.menu > li .content').css('position');
        },
        expected: 'absolute',
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list content padding top',
        points: 1,
        func: function () {
            return $('.menu > li .content p').offset().top - $('.menu > li .content').offset().top;
        },
        expected: 0,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list content padding bottom',
        points: 1,
        func: function () {
            return $('.menu > li .content p').offset().top + $('.menu > li .content p').height() - $('.menu > li .content').offset().top - $('.menu > li .content').height();
        },
        expected: -93,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list content padding left',
        points: 1,
        func: function () {
            return $('.menu > li .content p').offset().left - $('.menu > li .content').offset().left;
        },
        expected: 0,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list content padding right',
        points: 1,
        func: function () {
            return $('.menu > li .content p').offset().left + $('.menu > li .content p').width() - $('.menu > li .content').offset().left - $('.menu > li .content').width();
        },
        expected: -250,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list content border color',
        points: 1,
        func: function () {
            var leftColor = $('.menu > li .content').css('border-left-color');
            var rightColor = $('.menu > li .content').css('border-right-color');
            var topColor = $('.menu > li .content').css('border-top-color');
            var bottomColor = $('.menu > li .content').css('border-bottom-color');

            if (leftColor == rightColor && rightColor == topColor && bottomColor == topColor && leftColor == "rgb(0, 0, 0)") {
                return true;
            }
            else {
                return false;
            }
        },
        expected: true,
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list content border size',
        points: 1,
        func: function () {
            var leftColor = $('.menu > li .content').css('border-left-width');
            var rightColor = $('.menu > li .content').css('border-right-width');
            var topColor = $('.menu > li .content').css('border-top-width');
            var bottomColor = $('.menu > li .content').css('border-bottom-width');

            if (leftColor == rightColor && rightColor == topColor && bottomColor == topColor && leftColor == "1px") {
                return true;
            }
            else {
                return false;
            }
        },
        expected: true,
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list content border style',
        points: 1,
        func: function () {
            var leftColor = $('.menu > li .content').css('border-left-style');
            var rightColor = $('.menu > li .content').css('border-right-style');
            var topColor = $('.menu > li .content').css('border-top-style');
            var bottomColor = $('.menu > li .content').css('border-bottom-style');

            if (leftColor == rightColor && rightColor == topColor && bottomColor == topColor && leftColor == "solid") {
                return true;
            }
            else {
                return false;
            }
        },
        expected: true,
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list content border radius',
        points: 1,
        func: function () {
            var leftColor = $('.menu > li .content').css('border-top-left-radius');
            var rightColor = $('.menu > li .content').css('border-top-right-radius');
            var topColor = $('.menu > li .content').css('border-bottom-right-radius');
            var bottomColor = $('.menu > li .content').css('border-bottom-left-radius');

            if (leftColor == rightColor && rightColor == topColor && bottomColor == topColor) {
                return parseInt(leftColor);
            }
            else {
                return false;
            }
        },
        expected: 10,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list content gradient first color',
        points: 1,
        func: function () {
            var lis = $('.menu > li .content').css('linearGradientColors');
            return $.xcolor.distance('#feffff', lis[0]);
        },
        expected: 0,
        compare: 'equalDiff',
        compareParam: 30
    }, {
        name: 'menu list content gradient second color',
        points: 1,
        func: function () {
            var lis = $('.menu > li .content').css('linearGradientColors');
            return $.xcolor.distance('#a0d8ef', lis[1]);
        },
        expected: 0,
        compare: 'equalDiff',
        compareParam: 30
    }, {
        name: 'menu list content list square',
        points: 1,
        func: function () {
            return $('.menu > li .content ul').css('list-style-type');
        },
        expected: 'square',
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list content h3 underline',
        points: 1,
        func: function () {
            return $('.menu > li .content h3').css('text-decoration');
        },
        expected: 'underline',
        compare: 'equal',
        compareParam: null
    },{
        name: 'menu list hover a',
        points: 1,
        func: function () {
	        var el = $('.menu > li');
	        el.toggleClass('hover');
	        var value = $('.menu > li.hover > a').css('font-size');
	        el.toggleClass('hover');
	        return parseInt(value);
        },
        expected: 24,
        compare: 'equalDiff',
        compareParam: 4
    }, {
        name: 'menu list hover padding top',
        points: 1,
        func: function () {
            var el = $('.menu > li');
            el.toggleClass('hover');
            var value = $('.menu > li.hover > a').offset().top - $('.menu > li.hover').offset().top;
            el.toggleClass('hover');
            return value;
        },
        expected: -4,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list hover padding bottom',
        points: 1,
        func: function () {
            var el = $('.menu > li');
            el.toggleClass('hover');
            var value = $('.menu > li.hover a').offset().top + $('.menu > li.hover a').height() - $('.menu > li.hover').offset().top - $('.menu > li.hover').height();
            el.toggleClass('hover');
            return value;
        },
        expected: -4,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list hover padding left',
        points: 1,
        func: function () {
            var el = $('.menu > li');
            el.toggleClass('hover');
            var value = $('.menu > li.hover a').offset().left - $('.menu > li.hover').offset().left;
            el.toggleClass('hover');
            return value;
        },
        expected: 21,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list hover padding right',
        points: 1,
        func: function () {
            var el = $('.menu > li');
            el.toggleClass('hover');
            var value = $('.menu > li.hover a').offset().left + $('.menu > li.hover a').width() - $('.menu > li.hover').offset().left - $('.menu > li.hover').width();
            el.toggleClass('hover');
            return value;
        },
        expected: -29,
        compare: 'equalDiff',
        compareParam: 5
    }, {
        name: 'menu list hover display block',
        points: 1,
        func: function () {
            var el = $('.menu > li');
            el.toggleClass('hover');
            var value = $('.menu li.hover > .content').css('display');
            el.toggleClass('hover');
            return value;
        },
        expected: 'block',
        compare: 'equal',
        compareParam: null
    }, {
        name: 'menu list hover display block',
        points: 1,
        func: function () {
            return $('.bold').css('font-weight');
        },
        expected: 'bold',
        compare: 'equal',
        compareParam: null
    },
];

1) npm install
2) node server.js - runs on port 4444
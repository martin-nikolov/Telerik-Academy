define(function() {
  'use strict';
  var Container;
  Container = (function() {
   function Container() {
   
   }
   return Container;
  }());
  return Container;
});
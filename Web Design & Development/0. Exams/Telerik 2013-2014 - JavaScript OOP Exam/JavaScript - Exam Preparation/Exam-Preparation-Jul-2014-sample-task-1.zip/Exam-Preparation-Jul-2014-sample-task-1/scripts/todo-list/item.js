define(function() {
  'use strict';
  var Item;
  Item = (function() {
    function Item(content) {
	
    }
	
    return Item;
  })();
  return Item;
});
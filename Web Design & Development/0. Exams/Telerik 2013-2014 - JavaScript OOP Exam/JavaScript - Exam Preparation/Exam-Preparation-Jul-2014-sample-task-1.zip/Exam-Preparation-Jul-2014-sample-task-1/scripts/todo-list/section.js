define(function() {
  'use strict';
  var Section;
  Section = (function() {
    function Section(title) {
	
    }
	
	return Section;
  }());
  return Section;
}
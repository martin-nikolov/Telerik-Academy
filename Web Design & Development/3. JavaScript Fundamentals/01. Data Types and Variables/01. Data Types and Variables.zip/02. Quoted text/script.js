﻿/*
    2. Create a string variable with quoted text in it. 
    For example: 'How you doin'?', Joey said.
*/

taskName = "2. Quoted text";

function Main(bufferElement) {

    var quotedString = "Joey\'s \"How You Doin\'..?\"";
    WriteLine(quotedString + " -> " + "https://www.youtube.com/watch?v=43wkqM27z2E");
}
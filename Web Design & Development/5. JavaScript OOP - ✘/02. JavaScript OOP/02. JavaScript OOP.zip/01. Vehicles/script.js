﻿taskName = "1. Vehicles";

function Main(bufferElement) {
    SetConsoleSize(600);

    // You can find task code in scripts/main.js and other subfolders
}

﻿//interface IPropulsionUnit {
//    get acceleration(): number;
//}
//# sourceMappingURL=IPropulsionUnit.js.map

﻿var PropulsionUnits;
(function (PropulsionUnits) {
    (function (Interfaces) {
        "use strict";
    })(PropulsionUnits.Interfaces || (PropulsionUnits.Interfaces = {}));
    var Interfaces = PropulsionUnits.Interfaces;
})(PropulsionUnits || (PropulsionUnits = {}));
//# sourceMappingURL=PropulsionUnits.Interfaces.js.map

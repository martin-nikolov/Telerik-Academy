﻿var Vehicles;
(function (Vehicles) {
    (function (Interfaces) {
        "use strict";
    })(Vehicles.Interfaces || (Vehicles.Interfaces = {}));
    var Interfaces = Vehicles.Interfaces;
})(Vehicles || (Vehicles = {}));
//# sourceMappingURL=Vehicles.Interfaces.js.map

﻿var PropulsionUnitsModule;
(function (PropulsionUnitsModule) {
    var PropulsionUnits = PropulsionUnits;
    return PropulsionUnits;
})(PropulsionUnitsModule || (PropulsionUnitsModule = {}));
//# sourceMappingURL=PropulsionUnitsModule.js.map

## Events

1. Create a Simple JS Carousel with N images and two arrows for image control 
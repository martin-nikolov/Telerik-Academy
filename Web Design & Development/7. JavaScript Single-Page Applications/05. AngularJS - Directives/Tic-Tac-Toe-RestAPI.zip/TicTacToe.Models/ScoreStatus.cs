﻿namespace TicTacToe.Models
{
    using System;
    using System.Linq;

    public enum ScoreStatus
    {
        Win,
        Loss,
        Draw
    }
}
### Run the projects in the following order:
  1. RockBands.Services - must be started at first
  2. RockBands.ConsoleClient - seed data in the database + consuming Web API Services
  3. RockBands.WebClient - Web API Services consumer

__Change the Connection string -> RockBands.Common -> ConnectionStrings.cs__
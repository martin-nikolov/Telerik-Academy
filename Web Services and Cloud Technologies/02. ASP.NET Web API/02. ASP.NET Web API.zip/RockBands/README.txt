At first start the Console Client to seed the data.
Then start RockBands.Services and then RockBands.WebClient.
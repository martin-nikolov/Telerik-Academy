﻿namespace RockBands.Models.Projections
{
    using System;
    using System.Linq;

    public class FilterModel
    {
        public string BandSrc { get; set; }

        public int? Count { get; set; }
    }
}
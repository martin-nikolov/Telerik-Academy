﻿namespace TicTacToe.Common
{
    using System;
    using System.Linq;
    
    public class ConnectionStrings
    {
        public const string DefaultConnection = @"Data Source=.\sqlexpress;Initial Catalog=TicTacToe;Integrated Security=True";
    }
}
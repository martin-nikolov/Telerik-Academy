﻿namespace BugLogger.Common
{
    using System;
    using System.Linq;

    public static class ConnectionStrings
    {
        public const string BugLoggerConnectionString = @"Data Source=.\sqlexpress;Initial Catalog=BugLogger;Integrated Security=True";
    }
}
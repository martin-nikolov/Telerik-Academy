### Run the projects in the following order:
  1. BugLogger.ConsoleClient - create database + seed data
  2. BugLogger.Services - WebApi Controllers

__Change the Connection string -> BugLogger.Common -> ConnectionStrings.cs__ 
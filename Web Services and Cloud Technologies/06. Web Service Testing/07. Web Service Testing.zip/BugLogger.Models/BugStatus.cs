﻿namespace BugLogger.Models
{
    using System;
    using System.Linq;

    public enum BugStatus
    {
        Fixed,
        Assigned,
        ForTesting,
        Pending
    }
}
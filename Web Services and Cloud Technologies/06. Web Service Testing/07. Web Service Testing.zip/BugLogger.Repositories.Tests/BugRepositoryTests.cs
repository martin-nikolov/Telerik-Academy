﻿namespace BugLogger.Repositories.Tests
{
    using System;
    using System.Transactions;
    using BugLogger.Data;
    using BugLogger.Data.Repositories;
    using BugLogger.Models;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class BugRepositoryTests
    {
        private static TransactionScope transaction;

        [TestInitialize]
        public void Initialize()
        {
            transaction = new TransactionScope();
        }

        [TestCleanup]
        public void CleanUp()
        {
            transaction.Dispose();
        }

        [TestMethod]
        public void AddBug_WhenBugIsValid_ShouldAddToDatabase()
        {
            // Arrange -> Prepare the objects
            var bug = new Bug()
            {
                Description = "new bug",
                LogDate = DateTime.Now
            };
   
            // Act -> Test the objects
            var bugRepository = new BugRepository(new BugLoggerDbContext());
            bugRepository.Add(bug);
            bugRepository.SaveChanges();

            // Assert -> Validate the result
            var bugFromDb = bugRepository.Find(bug.BugId);

            Assert.IsNotNull(bugFromDb);
            Assert.AreEqual(bug.Description, bugFromDb);
        }
    }
}
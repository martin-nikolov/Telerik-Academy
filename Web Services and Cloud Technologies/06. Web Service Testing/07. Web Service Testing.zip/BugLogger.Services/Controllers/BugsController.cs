﻿namespace BugLogger.Services.Controllers
{
    using System;
    using System.Linq;
    using System.Web.Http;
    using BugLogger.Data;
    using BugLogger.Data.Contracts;
    using BugLogger.Models;
    using BugLogger.Services.Models;

    public class BugsController : ApiController
    {
        private readonly IBugLoggerData bugLoggerData;
  
        public BugsController()
            : this(new BugLoggerData())
        {
        }

        public BugsController(IBugLoggerData bugLoggerData)
        {
            this.bugLoggerData = bugLoggerData;
        }

        [HttpPost]
        public IHttpActionResult Create(CreateBugModel bugModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var bug = new Bug()
            {
                Description = bugModel.Description,
                LogDate = bugModel.LogDate,
                Status = bugModel.Status
            };

            this.bugLoggerData.Bugs.Add(bug);
            this.bugLoggerData.SaveChanges();

            return this.Ok(bug);
        }

        [HttpPost]
        public IHttpActionResult ChangeStatus(int id, BugStatus newStatus)
        {
            var bugFromDb = this.bugLoggerData.Bugs.Find(id);
            if (bugFromDb == null)
            {
                return this.BadRequest(string.Format("Bug with id={0} does not exists.", id));
            }

            bugFromDb.Status = newStatus;
            this.bugLoggerData.SaveChanges();

            return this.Ok(bugFromDb);
        }

        [HttpGet]
        public IQueryable<Bug> All()
        {
            return this.bugLoggerData.Bugs.All();
        }

        [HttpGet]
        public IQueryable<Bug> GetFromDate([FromUri]
                                           DateTime date)
        {
            return this.bugLoggerData.Bugs.GetAllFromDate(date);
        }

        [HttpGet]
        public IQueryable<Bug> GetToDate([FromUri]
                                         DateTime date)
        {
            return this.bugLoggerData.Bugs.GetAllToDate(date);
        }

        [HttpGet]
        public IQueryable<Bug> GetInDateRange([FromUri]
                                              DateTime fromDate, DateTime toDate)
        {
            return this.bugLoggerData.Bugs.GetAllInDateRange(fromDate, toDate);
        }

        [HttpGet]
        public IQueryable<Bug> GetByStatus([FromUri]
                                           BugStatus type)
        {
            return this.bugLoggerData.Bugs.GetAllByStatus(type);
        }

        [HttpGet]
        public int Count()
        {
            return this.bugLoggerData.Bugs.All().Count();
        }
    }
}
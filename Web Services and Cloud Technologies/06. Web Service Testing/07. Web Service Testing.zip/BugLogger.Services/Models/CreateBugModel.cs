﻿namespace BugLogger.Services.Models
{
    using System;
    using System.Linq;
    using BugLogger.Models;

    public class CreateBugModel
    {
        public string Description { get; set; }

        public DateTime LogDate { get; set; }

        public BugStatus Status { get; set; }
    }
}